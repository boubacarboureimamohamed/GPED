<?php
     include('shared/function/connect.php');

     ob_start(); 
?>
<style type="text/css">
    p{margin: 0; padding: 2mm 0;}
    hr{ background:#717375; height:1mm; border:none;}
    h2{color: #000; margin: 0; padding: 0;}
    table{border-collapse: collapse; width: 100%; font-size: 12pt; font-family: helvetica; line-height: 7mm; letter-spacing: 1px;}
    td.right{text-align: right;  font-size: 13pt;}
    td.right1{text-align: right;}
    td.num{font-size: 15pt;}
    strong.logo{font-size: 15pt;}
    table.border td{border:1px solid:#CFD1D2; padding: 3mm 1mm; }
    table.border th,td.black{background: #000; color: #FFF; font-weight: normal; border: solid 1 #FFF; padding: 2mm 1mm; text-align: left; }
    td.noborder{border:none;}
</style>

    <?php
            $print_bon=$_GET["Print"];
            $_POST['num_bon']=$print_bon;

            $reponse8 = $maConnexion->query("SELECT * FROM bon_engagement, type_bon_engagement, section, gestion, service, depense, reglement, fournisseur, programme, action, tache, compte, activite WHERE bon_engagement.id_type = type_bon_engagement.id_type AND bon_engagement.code_section = section.code_section AND bon_engagement.id_gestion = gestion.id_gestion AND bon_engagement.code_service = service.code_service AND bon_engagement.code_depense = depense.code_depense AND bon_engagement.code_reglement = reglement.code_reglement AND bon_engagement.nif_frs = fournisseur.nif_frs AND bon_engagement.code_programme = programme.code_programme AND bon_engagement.code_action = action.code_action AND bon_engagement.code_tache = tache.code_tache AND bon_engagement.code_compte = compte.code_compte AND bon_engagement.code_activite = activite.code_activite AND etat = 1 AND num_bon='$print_bon'");

                while ($affichages8 = $reponse8->fetch())
                         {
                                                          
        ?>

 <page backtop="15mm" backleft="10mm" backright="10mm" backbottom="30mm" footer="page">
    <h1 style="text-align: center;">    
         <strong>TITRE DE CREANCE - ORIGINAL</strong><hr/>
    </h1>
    <page_footer>
        <hr/>
        <h2>Titre de créance</h2>
        <p style="text-align: center;"> (Centre comptable pour la mise en réglement) </p>
    </page_footer>
    
    <table style="vertical-align: top;">
        <tr>
            <td style="width: 60%;">
                <strong class="logo">REPUBLIQUE DU NIGER </strong><br/>
            </td>
            <td style="width: 40%;">
                <strong>NATURE DU DOCUMENT</strong>
            </td>
        </tr>
        <tr>
            <td style="width: 70%;">
                <strong class="logo">MINISTERE DES FINANCES </strong><br/>
            </td>
            <td style="width: 30%;">
                <strong>CREANCE - </strong> <?php echo $affichages8['gestion']; ?>
            </td>
        </tr>
    </table>
    <table style="line-height: 5mm; margin-top: 5mm; text-align: center; letter-spacing: 1px;;">
        <tr>
            <td style="width: 100%;">
                <strong>CENTRE COMPTABLE : </strong><br/>
            </td>
        </tr>
    </table>
    <table class="border"  style=" margin-top: 5mm;">
        <thead>
            <tr>
                <th style="width: 25%; text-align: center;">BON N° </th>
                <th style="width: 50%; text-align: center;">IMPUTATION</th>
                <th style="width: 25%; text-align: center;">MONTATNT</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="text-align: center;"> <?php echo $affichages8["num_bon"]; ?> </td>
                <td style="text-align: center;"> <?php echo $affichages8["code_imputation"]; ?> </td>
                <td style="text-align: center;"> <?php echo $affichages8['montant_total']; ?> </td>
            </tr>
            <tr>
                <td style="text-align: center;"> Numéro</td>
                <td style="text-align: center;"> </td>
                <td style="text-align: center; line-height: 3mm;"> Francs CFA</td>
            </tr>
        </tbody>
    </table>
    <p style="margin-left: 10mm; margin-top: 3mm;"><strong>Visa</strong></p>
    <p style="margin-top: -3mm;"><strong>Contrôleur Financier</strong></p>
    <table style="line-height: 5mm; margin-top: -15mm;">
        <tr>
            <td style="width: 25%;">

            </td>
            <td style="width: 100%; line-height: 5mm;">
                <table class="border"  style="width: 75%; margin-top: 5mm;">
                    <thead>
                        <tr>
                            <th colspan="2" style="text-align: center; width: 100%; letter-spacing: 10px; font-size: 15pt;">DESTINATAIRE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="text-align: center; width: 25%;"> Agent </td>
                            <td style="text-align: center; width: 75%;"> Immatriculé</td>
                        </tr>
                        <tr>
                            <td style="text-align: center;"> Nom & Prénom </td>
                            <td style="text-align: center;"> <?php echo $affichages8['nom']; ?> <?php echo $affichages8['prenom']; ?></td>
                        </tr>
                        <tr>
                            <td style="text-align: center;"> Nif_Frs </td>
                            <td style="text-align: center;"> <?php echo $affichages8['nif_frs']; ?> </td>
                        </tr>
                    </tbody>
                </table>
                <table style="width: 75%; line-height: 5mm;">
                    <tr>
                        <td style=" line-height: 5mm;">
                            <table class="border"  style=" margin-top: 5mm;">
                                <thead>
                                    <tr>
                                        <th style="text-align: center; width: 89%;">MINISTERE SERVICE EMETTEUR</th>
                                        <th style="text-align: center; width: 11%;">Code</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td style="text-align: center;"> <?php echo $affichages8['libelle_section']; ?> </td>
                                        <td style="text-align: center;"> <?php echo $affichages8['code_section']; ?> </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <table class="border"  style=" margin-top: 5mm; line-height: 5mm;">
        <thead>
            <tr>
                <th style="width: 49%; text-align: center;">Références de la facture </th>
                <th style="width: 20%; text-align: center;">Date</th>
                <th style="width: 11%; text-align: center;">Numéro</th>
                <th style="width: 20%; text-align: center;">Montant (FCFA)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="text-align: center;">  </td>
                <td style="text-align: center;"> </td>
                <td style="text-align: center;">  </td>
                <td style="text-align: center;">  </td>
            </tr>
        </tbody>
    </table>
    <table style="line-height: 7mm; margin-top: 10mm;">
        <tr>
            <td style="width: 45%; line-height: 7mm;">
                <strong> Visa du centre comptable : </strong> <br/>
            </td>
            <td style="width: 20%; line-height: 7mm;" >
                <strong> Bon à payer : </strong> <br/>
            </td>
            <td style="width: 33%; line-height: 7mm;" class="right1">
                <strong> Visa du trésor </strong> <br/>
            </td>
        </tr>
    </table>

</page>

 <page backtop="15mm" backleft="10mm" backright="10mm" backbottom="30mm" footer="page">
    <h1 style="text-align: center;">    
         <strong>TITRE DE CREANCE - ORIGINAL</strong><hr/>
    </h1>
    <page_footer>
        <hr/>
        <h2>Titre de créance</h2>
        <p>Niamey, le ___________________________________________ 20____</p>
        <p style="text-align: center;"> (Centre comptable pour la mise en réglement) </p>
    </page_footer>

   <table style="vertical-align: top;">
        <tr>
            <td style="width: 60%;">
                <strong class="logo">REPUBLIQUE DU NIGER </strong><br/>
            </td>
            <td style="width: 40%;">
                <strong>NATURE DU DOCUMENT</strong>
            </td>
        </tr>
        <tr>
            <td style="width: 70%;">
                <strong class="logo">MINISTERE DES FINANCES </strong><br/>
            </td>
            <td style="width: 30%;">
                <strong>CERTIFICATION - </strong> <?php echo $affichages8['gestion']; ?>
            </td>
        </tr>
    </table>
    <table style="line-height: 5mm; margin-top: 5mm; text-align: center; letter-spacing: 1px;;">
        <tr>
            <td style="width: 100%;">
                <strong>CENTRE COMPTABLE : </strong><br/>
            </td>
        </tr>
    </table>
    <table class="border"  style=" margin-top: 5mm;">
        <thead>
            <tr>
                <th style="width: 25%; text-align: center;">BON N° </th>
                <th style="width: 50%; text-align: center;">IMPUTATION</th>
                <th style="width: 25%; text-align: center;">MONTATNT</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="text-align: center;"> <?php echo $affichages8['num_bon']; ?> </td>
                <td style="text-align: center;"> <?php echo $affichages8['code_imputation']; ?> </td>
                <td style="text-align: center;"> <?php echo $affichages8['montant_total']; ?> </td>
            </tr>
            <tr>
                <td style="text-align: center;"> Numéro</td>
                <td style="text-align: center;"> </td>
                <td style="text-align: center; line-height: 3mm;"> Francs CFA</td>
            </tr>
        </tbody>
    </table>
    <p style="margin-left: 8mm; margin-top: 3mm;"><strong>Code dépense : </strong></p>
    <p style="margin-left: 15mm; margin-top: 1mm;"><strong> <?php echo $affichages8['code_depense']; ?><?php echo $affichages8['code_reglement']; ?> </strong></p>
    <p style="margin-top: 5mm;"><strong>Aprés cet engagement </strong></p>
    <p style="margin-left: 2mm;"><strong>votre disponible sur </strong></p>
    <p style="margin-left: 3mm;"><strong>la rubrique est de :  </strong></p>
    <p style="margin-left: 10mm; margin-top: 5mm;"><strong> <?php echo $affichages8['disponible_apres']; ?> FCFA</strong></p>
    <table style="line-height: 5mm; margin-top: -15mm;">
        <tr>
            <td style="width: 25%;">

            </td>
            <td style="width: 100%; line-height: 5mm;">
                <table class="border"  style="width: 75%; margin-top: -40mm;">
                    <thead>
                        <tr>
                            <th colspan="2" style="text-align: center; width: 100%; letter-spacing: 10px; font-size: 15pt;">FOURNISSEUR OU BENEFICIAIRE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="text-align: center; width: 25%;"> Agent </td>
                            <td style="text-align: center; width: 75%;"> Immatriculé</td>
                        </tr>
                        <tr>
                            <td style="text-align: center;"> Nom & Prénom </td>
                            <td style="text-align: center;"> <?php echo $affichages8['nom']; ?> <?php echo $affichages8['prenom']; ?></td>
                        </tr>
                        <tr>
                            <td style="text-align: center;"> Nif_Frs </td>
                            <td style="text-align: center;"> <?php echo $affichages8['nif_frs']; ?> </td>
                        </tr>
                    </tbody>
                </table>
                <table style="width: 75%; line-height: 5mm;">
                    <tr>
                        <td style=" line-height: 5mm;">
                            <table class="border"  style=" margin-top: 5mm;">
                                <thead>
                                    <tr>
                                        <th style="text-align: center; width: 89%;">MINISTERE SERVICE EMETTEUR</th>
                                        <th style="text-align: center; width: 11%;">Code</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td style="text-align: center;"> <?php echo $affichages8['libelle_section']; ?> </td>
                                        <td style="text-align: center;"> <?php echo $affichages8['code_section']; ?> </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <table class="border"  style=" margin-top: 5mm; line-height: 5mm;">
        <thead>
            <tr>
                <th style="width: 49%; text-align: center;">Enregistrement au journal des prises en charge </th>
                <th style="width: 20%; text-align: center;">Date</th>
                <th style="width: 11%; text-align: center;">Numéro</th>
                <th style="width: 20%; text-align: center;">Montant (FCFA)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="text-align: center;"> </td>
                <td style="text-align: center;"> </td>
                <td style="text-align: center;">  </td>
                <td style="text-align: center;">  </td>
            </tr>
        </tbody>
    </table>
    <table style="line-height: 7mm; margin-top: 10mm;">
        <tr>
            <td style="width: 34%; line-height: 7mm;">
                <strong>Certifié le service fait : </strong> <br/>
            </td>
            <td style="width: 33%; line-height: 7mm;" >
                <strong>Visa du centre comptable : </strong> <br/>
            </td>
            <td style="width: 33%; line-height: 7mm;" class="right1">
                <strong> Signature et Cachet </strong> <br/>
            </td>
        </tr>
    </table>
</page>

    <?php 
            }
      ?>

<?php 
$content=ob_get_clean();
require('html2pdf/html2pdf.class.php');
try{
$pdf= new HTML2PDF('P', 'A4', 'fr', 'true', 'UTF-8');
$pdf->pdf->SetDisplayMode('fullpage');
$pdf->writeHTML($content);
    ob_get_clean();
$pdf->Output('bon_engagement.pdf');
}
catch(HTML2PDF_exception $e){ 
die ($e);}
?>