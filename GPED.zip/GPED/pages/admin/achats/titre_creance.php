<?php 
     session_start(); 
?> 
<?php
     include('shared/partials/header.php');

     include('shared/partials/menu1.php');

     include('shared/function/connect.php');
?> 

<!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="page-header" style="text-align: center;"><b>Liste des bons d'engagements validés</b></h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12"><br>
                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                            <tr>
                                                <th>Bon N°</th>
                                                <th>Type Bon</th>
                                                <th>Imputation</th>
                                                <th>Ministére</th>
                                                <th>Nif_Frs / Mle</th>
                                                <th>Date Validation</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <?php
                                             $reponse = $maConnexion->query('SELECT * FROM bon_engagement, type_bon_engagement, section, gestion, service, depense, reglement, fournisseur, programme, action, tache, compte, activite WHERE bon_engagement.id_type = type_bon_engagement.id_type AND bon_engagement.code_section = section.code_section AND bon_engagement.id_gestion = gestion.id_gestion AND bon_engagement.code_service = service.code_service AND bon_engagement.code_depense = depense.code_depense AND bon_engagement.code_reglement = reglement.code_reglement AND bon_engagement.nif_frs = fournisseur.nif_frs AND bon_engagement.code_programme = programme.code_programme AND bon_engagement.code_action = action.code_action AND bon_engagement.code_tache = tache.code_tache AND bon_engagement.code_compte = compte.code_compte AND bon_engagement.code_activite = activite.code_activite AND etat =1 ORDER BY num_bon ASC');
                                              
                                        ?>
                                        <tbody>
                                          <?php  
                                             while ($affichages = $reponse->fetch())
                                                 {
                                          ?>
                                            <tr>
                                                <td><?php echo $affichages['num_bon']; ?></td>
                                                <td><?php echo $affichages['type']; ?></td>
                                                <td><?php echo $affichages['code_imputation']; ?></td>
                                                <td><?php echo $affichages['libelle_section']; ?></td>
                                                <td><?php echo $affichages['nif_frs']; ?></td>
                                                <td><?php echo $affichages['date_valide']; ?></td>
                                                <td>
                                                  <a href="print_creance.php?Print=<?php echo $affichages['num_bon']; ?>">
                                                      <button type="button" class="btn btn-success"><i class="fa fa-credit-card fa-fw"></i> Créance </button>
                                                  </a>
                                                </td>
                                            </tr> 
                                            
                                        <?php
                                                }
                                             $reponse->closeCursor();
                                        ?>

                                        </tbody>
                                    </table>
                        </div>
                    </div>
                </div>
                </div>
            <!-- /#page-wrapper -->
<?php
     include('shared/partials/footer.php');
?>