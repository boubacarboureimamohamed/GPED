<?php 
     session_start(); 
?>
<?php
     include('shared/partials/header.php');

     include('shared/partials/menu1.php'); 

     include('shared/function/connect.php');
?>             

        <?php
            $reponse = $maConnexion->query('SELECT F.nif_frs, F.nom, F.prenom, F.ville, F.pays, F.adresse FROM fournisseur F ORDER BY F.nif_frs ASC');
            $reponse1 = $maConnexion->query('SELECT S.code_service, S.libelle_service FROM service S ORDER BY S.code_service ASC');
            $reponse2 = $maConnexion->query('SELECT SC.code_section, SC.libelle_section FROM section SC ORDER BY SC.code_section ASC');
            $reponse3 = $maConnexion->query('SELECT T.id_type, T.type FROM type_bon_engagement T ORDER BY T.id_type ASC');
            $reponse4 = $maConnexion->query('SELECT G.id_gestion, G.gestion FROM gestion G ORDER BY G.id_gestion ASC');
            $reponse5 = $maConnexion->query('SELECT F.nif_frs, F.nom, F.prenom, F.ville, F.pays, F.adresse FROM fournisseur F ORDER BY F.nif_frs ASC');
            $reponse6 = $maConnexion->query('SELECT R.code_reglement, R.libelle_reglement FROM reglement R ORDER BY R.code_reglement ASC');
            $reponse7 = $maConnexion->query('SELECT D.code_depense, D.libelle_depense FROM depense D ORDER BY D.code_depense ASC');
        ?>

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12"  style="padding-top: 25px;">
                          <div class="panel panel-default">
                            <div class="panel-heading" style="text-align: center; font-size: 20px;">
                                <b>AJOUT D'UN NOUVEAU BON D'ENGAGEMENT</b>
                            </div>
                            <div class="panel-body">
                                <form action="shared/function/insert_bon.php" method="post" onsubmit="return verifForm(this)">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">Dépense :</label>
                                            <div class="col-md-8">
                                               <select class="form-control input-sm" name="depense" id="opt" name="depense" required="required">
                                                    <option>---------------------select---------------------</option>
                                                    <?php while ($affichages7 = $reponse7->fetch())
                                                        {
                                                     ?>
                                                    <option value="<?php echo $affichages7['code_depense']?>"><?php echo $affichages7['libelle_depense']; ?></option>
                                                    <?php
                                                        }
                                                      $reponse->closeCursor();
                                                    ?>
                                               </select>
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">Réglement :</label>
                                            <div class="col-md-8">
                                               <select class="form-control input-sm" name="reglement" id="opt" name="reglement" required="required">
                                                    <option>---------------------select---------------------</option>
                                                    <?php while ($affichages6 = $reponse6->fetch())
                                                        {
                                                     ?>
                                                    <option value="<?php echo $affichages6['code_reglement']?>"><?php echo $affichages6['libelle_reglement']; ?></option>
                                                    <?php
                                                        }
                                                      $reponse->closeCursor();
                                                    ?>
                                               </select>
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">Nature de la dépense :</label>
                                               <div class="col-md-8">
                                                     <textarea class="form-control" id="libelle" name="nature_depense" rows="1" onblur="veriflibelle(this)"></textarea> 
                                              </div>
                                        </div><br><br>
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">Réf - Piéces justificatives :</label>
                                               <div class="col-md-8">
                                                     <textarea name="ref_piece" id="piece" class="form-control" onblur="verifpiece(this)" rows="1" required="required"></textarea> 
                                              </div>
                                        </div><br><br>
                                        <div class="form-group">
                                            <label for="programme" class="col-md-3 control-label">Programme:</label>
                                            <div class="col-md-3">
                                               <input type="number" id="programme" name="code_programme" class="form-control input-sm" placeholder="Code" autocomplete="off" onblur="verifprogramme(this)">
                                            </div>
                                            <div class="col-md-6">
                                               <input type="text" id="libelle" name="libelle_programme" class="form-control input-sm" placeholder="Libellé" autocomplete="off" onblur="veriflibelle(this)">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Action  :</label>
                                            <div class="col-md-3">
                                               <input type="number" id="Action" name="code_action" class="form-control input-sm" placeholder="Code" autocomplete="off" onblur="verifaction(this)">
                                            </div>
                                            <div class="col-md-6">
                                               <input type="text" id="libelle" name="libelle_action" class="form-control input-sm" placeholder="Libellé" autocomplete="off" onblur="veriflibelle(this)">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Activité :</label>
                                            <div class="col-md-3">
                                               <input type="number" id="activite" name="code_activite" class="form-control input-sm" placeholder="Code" autocomplete="off" onblur="verifactivite(this)">
                                            </div>
                                            <div class="col-md-6">
                                               <input type="text" id="libelle" name="libelle_activite" class="form-control input-sm" placeholder="Libellé" autocomplete="off" onblur="veriflibelle(this)">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Tâche :</label>
                                            <div class="col-md-3">
                                               <input type="number" id="tache" name="code_tache" class="form-control input-sm" placeholder="Code" autocomplete="off" onblur="veriftache(this)">
                                            </div>
                                            <div class="col-md-6">
                                               <input type="text" id="libelle" name="libelle_tache" class="form-control input-sm" placeholder="Libellé" autocomplete="off" onblur="veriflibelle(this)">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Compte :</label>
                                            <div class="col-md-3">
                                               <input type="number" id="compte" name="code_compte" class="form-control input-sm" placeholder="Code" autocomplete="off" onblur="verifcompte(this)">
                                            </div>
                                            <div class="col-md-6">
                                               <input type="text" id="libelle" name="intitule" class="form-control input-sm" placeholder="Libellé" autocomplete="off" onblur="veriflibelle(this)">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Quntité :</label>
                                            <div class="col-md-3">
                                               <input type="number" value="" id="quantite" name="quantite" class="form-control input-sm" placeholder="Qté..?" autocomplete="off">
                                            </div>
                                            <label class="col-md-2 control-label">Prix_U:</label>
                                            <div class="col-md-4">
                                               <input type="number" value="" id="pu" name="pu" class="form-control input-sm" placeholder="Quel prix...?" autocomplete="off">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-6 control-label">Montant Total :</label>
                                            <div class="col-md-6">
                                               <input type="text" id="montant_total" name="montant_total" class="form-control input-sm" placeholder="Quel montant....................?" disabled="true" autocomplete="off">
                                               <input type="hidden" id="montant_total_1" name="montant_total_1" class="form-control input-sm" placeholder="Quel montant....................?" autocomplete="off"> 
                                            </div>
                                        </div><br>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="col-md-8 control-label"><h4>REPUBLIQUE DU NIGER</h4></label>
                                            <div class="col-md-4">
                                               <select name="exercice" class="form-control input-sm">
                                                    <option value="">--gestion--</option>
                                                    <?php while ($affichages4 = $reponse4->fetch())
                                                        {
                                                     ?>
                                                    <option value="<?php echo $affichages4['id_gestion']?>"><?php echo $affichages4['gestion']; ?></option>
                                                    <?php
                                                        }
                                                      $reponse->closeCursor();
                                                    ?>
                                               </select>
                                            </div>
                                        </div><br><br>
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">MINISTERE :</label>
                                            <div class="col-md-8">
                                               <select name="ministere" class="form-control input-sm">
                                                    <option>--------------------select-------------------------------------------------------------------</option>
                                                    <?php while ($affichages2 = $reponse2->fetch())
                                                        {
                                                     ?>
                                                    <option value="<?php echo $affichages2['code_section']?>"><?php echo $affichages2['libelle_section']; ?></option>
                                                    <?php
                                                        }
                                                      $reponse->closeCursor();
                                                    ?>
                                               </select>
                                            </div>
                                        </div><br><br>
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">SERVICE EMETTEUR :</label>
                                            <div class="col-md-8">
                                               <select name="service" class="form-control input-sm">
                                                    <option>--------------------select--------------------------------------------------------------------</option>
                                                    <?php while ($affichages1 = $reponse1->fetch())
                                                        {
                                                     ?>
                                                    <option value="<?= $affichages1['code_service']?>"><?php echo $affichages1['libelle_service']; ?></option>
                                                    <?php
                                                        }
                                                      $reponse->closeCursor();
                                                    ?>
                                               </select>
                                            </div>
                                        </div><br><br>
                                        <div class="form-group">
                                            <label for="imputation" class="col-md-4 control-label">Imputation :</label>
                                            <div class="col-md-8">
                                                 <input type="number" id="imputation" name="code_imputation" class="form-control input-sm" placeholder="Code Imputation" required="required" autocomplete="off" onblur="verifimputation(this)"> 
                                            </div>
                                        </div><br><br>
                                        <div class="form-group">
                                            <label class="col-md-6 control-label">Type bon :</label>
                                            <div class="col-md-6">
                                               <select name="type_bon" class="form-control input-sm">
                                                    <option>------------select---------------</option>
                                                    <?php while ($affichages3 = $reponse3->fetch())
                                                        {
                                                     ?>
                                                    <option value="<?php echo $affichages3['id_type']?>"><?php echo $affichages3['type']; ?></option>
                                                    <?php
                                                        }
                                                      $reponse->closeCursor();
                                                    ?>
                                               </select>
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-6 control-label">Crédits disponibles :</label>
                                            <div class="col-md-6">
                                               <input type="number" id="credit_disponible" name="credit_disponible" class="form-control input-sm" placeholder="Crédits disponibles.......?" required="required" autocomplete="off">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-6 control-label">Montant engagé :</label>
                                            <div class="col-md-6">
                                               <input type="number" id="montant_engage" name="montant_engage" class="form-control input-sm" placeholder="Quel montant................?" required="required" autocomplete="off" disabled="true">
                                               <input type="hidden" id="montant_engage_1" name="montant_engage_1" class="form-control input-sm" placeholder="Quel montant................?" required="required" autocomplete="off">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-6 control-label">Disponible aprés :</label>
                                            <div class="col-md-6">
                                               <input type="number" id="disponible_apres" name="disponible_apres" class="form-control input-sm" placeholder="Disponibles aprés.........?" required="required" autocomplete="off" disabled="true">
                                               <input type="hidden" id="disponible_apres_1" name="disponible_apres_1" class="form-control input-sm" placeholder="Disponible aprés............?" required="required" autocomplete="off">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-6 control-label">Fournisseur :</label>
                                            <div class="col-md-6">
                                                 <select name="nif_frs" class="form-control input-sm">
                                                    <option value="">NIF_Frs / Matricule</option>
                                                    <?php while ($affichages5 = $reponse5->fetch())
                                                        {
                                                     ?>
                                                    <option value="<?php echo $affichages5['nif_frs']?>"><?php echo $affichages5['nif_frs']; ?></option>
                                                    <?php
                                                        }
                                                      $reponse->closeCursor();
                                                    ?>
                                               </select>
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-6 control-label">Date du bon :</label>
                                            <div class="col-md-6">
                                               <input type="date" min="<?= date('Y-m-d') ?>" max="<?= date('Y-m-d') ?>" name="date_bon" formnovalidate="aaaa-mm-jj" class="form-control input-sm">
                                            </div>
                                        </div>
                                    </div>
                            </div>
                             <div class="panel-footer">
                               <div style="text-align: center; ">
                                 <a href="liste_engagement.php"><button type="button" class="btn btn-default"> Annuler</button></a>
                                 <button type="submit" id="action" name="action" class="btn btn-success"><i class="fa fa-save fa-fw"></i> Ajouter</button>
                              </div>
                              </form>
                             </div>
                                 
                             </div> 
                         </div>       
                        </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->

<?php
     include('shared/function/script2.php'); 
     include('shared/partials/footer.php');
?> 
