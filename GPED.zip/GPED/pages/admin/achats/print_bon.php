<?php
     include('shared/function/connect.php');

     ob_start();
?>
<style type="text/css">
    p{margin: 0; padding: 2mm 0;}
    hr{ background:#717375; height:1mm; border:none;}
    h2{color: #000; margin: 0; padding: 0;}
    table{border-collapse: collapse; width: 100%; font-size: 12pt; font-family: helvetica; line-height: 7mm; letter-spacing: 1px;}
    td.right{text-align: right;  font-size: 13pt;}
    td.right1{text-align: right;}
    td.num{font-size: 15pt;}
    strong.logo{font-size: 15pt;}
    table.border td{border:1px solid:#CFD1D2; padding: 3mm 1mm; }
    table.border th,td.black{background: #000; color: #FFF; font-weight: normal; border: solid 1 #FFF; padding: 2mm 1mm; text-align: left; }
    td.noborder{border:none;}
</style>
        <?php
            $print_bon=$_GET["Print"];
            $_POST['num_bon']=$print_bon;
            $reponse8 = $maConnexion->query("SELECT * FROM bon_engagement, type_bon_engagement, section, gestion, service, depense, reglement, fournisseur, programme, action, tache, compte, activite WHERE bon_engagement.id_type = type_bon_engagement.id_type AND bon_engagement.code_section = section.code_section AND bon_engagement.id_gestion = gestion.id_gestion AND bon_engagement.code_service = service.code_service AND bon_engagement.code_depense = depense.code_depense AND bon_engagement.code_reglement = reglement.code_reglement AND bon_engagement.nif_frs = fournisseur.nif_frs AND bon_engagement.code_programme = programme.code_programme AND bon_engagement.code_action = action.code_action AND bon_engagement.code_tache = tache.code_tache AND bon_engagement.code_compte = compte.code_compte AND bon_engagement.code_activite = activite.code_activite AND num_bon='$print_bon'");

                while ($affichages8 = $reponse8->fetch())
                         {
                                                          
        ?>
 <page backtop="15mm" backleft="10mm" backright="10mm" backbottom="30mm" footer="page">
    <h1 style="text-align: center;">    
         <strong>BON D'ENGAGEMENT - ORIGINAL</strong><hr/>
    </h1>
    <page_footer>
        <hr/>
        <h2>Bon d'engagement</h2>
        <p style="text-align: center;"> (Chef de service ou Administrateur des crédits) </p>
    </page_footer>
    
    <table style="vertical-align: top;">
        <tr>
            <td style="width: 80%;">
                <strong class="logo">REPUBLIQUE DU NIGER </strong><br/>
            </td>
            <td style="width: 20%;">
                <strong>Gestion : </strong> <?php echo $affichages8['gestion']; ?>
            </td>
        </tr>
    </table>
    <table style="line-height: 7mm; margin-top: 5mm; letter-spacing: 1px;;">
        <tr>
            <td style="width: 100%;">
                <strong>Ministére : </strong> <?php echo $affichages8['libelle_section']; ?><br/>
            </td>
        </tr>
    </table>
    <table style="line-height: 7mm; margin-top: 5mm;">
        <tr>
            <td style="width: 100%;">
                <strong>Service Emetteur : </strong> <?php echo $affichages8['libelle_service']; ?><br/>
            </td>
        </tr>
    </table>
    <table style="line-height: 7mm; margin-top: 5mm;">
        <tr>
            <td style="width: 50%; line-height: 7mm;">
                <strong>Dépense : </strong> <?php echo $affichages8['libelle_depense']; ?><br/>
            </td>
            <td style="width: 50%; line-height: 7mm;" class="right1">
                <strong>Réglement : </strong> <?php echo $affichages8['libelle_reglement']; ?><br/>
            </td>
        </tr>
    </table>
    <table style="line-height: 7mm; margin-top: 5mm;">
        <tr>
            <td style="width: 100%;">
                <strong>Nature de la dépense : </strong> <?php echo $affichages8["nature_depense"]; ?><br/>
            </td>
        </tr>
    </table>
    <table style="line-height: 7mm; margin-top: 5mm;">
        <tr>
            <td style="width: 100%;">
                <strong>Réféence - Piéce Justificative : </strong> <?php echo $affichages8["ref_piece"]; ?><br/>
            </td>
        </tr>
    </table>
    <table style="vertical-align: bottom; margin-top: 20mm;">
        <tr>
            <td style="width: 50%;" class="num">
                <strong>Bon N° : </strong> <?php echo $affichages8["num_bon"]; ?><br/>
            </td>
            <td style="width: 50%;" class="right">
                <strong>Type Bon : </strong> <?php echo $affichages8['type']; ?><br/>
            </td>
        </tr>
    </table>
    <table class="border"  style=" margin-top: 15mm;">
        <thead>
             <tr>
                <th colspan="5" style="text-align: center; letter-spacing: 10px; font-size: 15pt;">DETAIL DU BON</th>
            </tr>
            <tr>
                <th style="width: 8%;">Code</th>
                <th style="width: 48%;">Libellé</th>
                <th style="width: 11%;">Quantité</th>
                <th style="width: 16%;">Prix Unitaire</th>
                <th style="width: 17%;">Montant</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td> <?php echo $affichages8['code_programme']; ?></td>
                <td> <?php echo $affichages8['libelle_programme']; ?></td>
                <td style="text-align: center;"> X </td>
                <td style="text-align: center;"> X </td>
                <td style="text-align: center;"> X </td>
            </tr>
            <tr>
                <td> <?php echo $affichages8['code_action']; ?></td>
                <td> <?php echo $affichages8['libelle_action']; ?></td>
                <td style="text-align: center;"> X </td>
                <td style="text-align: center;"> X </td>
                <td style="text-align: center;"> X </td>
            </tr>
            <tr>
                <td> <?php echo $affichages8['code_activite']; ?></td>
                <td> <?php echo $affichages8['libelle_activite']; ?></td>
                <td style="text-align: center;"> X </td>
                <td style="text-align: center;"> X </td>
                <td style="text-align: center;"> X </td>
            </tr>
            <tr>
                <td> <?php echo $affichages8['code_tache']; ?></td>
                <td> <?php echo $affichages8['libelle_tache']; ?></td>
                <td style="text-align: center;"> X </td>
                <td style="text-align: center;"> X </td>
                <td style="text-align: center;"> X </td>
            </tr>
            <tr>
                <td> <?php echo $affichages8['code_compte']; ?></td>
                <td> <?php echo $affichages8['intitule']; ?></td>
                <td style="text-align: center;"> <?php echo $affichages8['quantite']; ?></td>
                <td style="text-align: center;"> <?php echo $affichages8['pu']; ?> FCFA</td>
                <td style="text-align: center;"> <?php echo $affichages8['montant_total']; ?> FCFA</td>

            </tr>
            <tr>
                <td colspan="2" class="noborder" style="padding: 1mm;"></td>
                <td colspan="2" class="black" style="padding: 1mm; text-align: center;"> Montant Total : </td>
                <td style="padding: 1mm; text-align: center;"> <?php echo $affichages8['montant_total']; ?> FCFA</td>
            </tr>
        </tbody>
    </table>

</page>

 <page backtop="15mm" backleft="10mm" backright="10mm" backbottom="30mm" footer="page">
    <h1 style="text-align: center;">    
         <strong>BON D'ENGAGEMENT - ORIGINAL</strong><hr/>
    </h1>
    <page_footer>
        <hr/>
        <h2>Bon d'engagement</h2>
        <p>Niamey, le ___________________________________________ 20____</p>
        <p style="text-align: center;"> (Chef de service ou Administrateur des crédits) </p>
    </page_footer>

    <table style="vertical-align: bottom; text-align: center;">
        <tr>
            <td style="width: 50%;">
                <strong class="logo">CODE IMPUTATION : </strong> <br/>
            </td>
            <td style="width: 50%;">
                <strong><?php echo $affichages8["code_imputation"]; ?></strong> 
            </td>
        </tr>
    </table>
    <table style="vertical-align: bottom; text-align: center; margin-top: 5mm;">
        <tr>
            <td style="width: 50%;">
                <strong>Crédits Disponibles : </strong> <br/>
            </td>
            <td style="width: 50%;">
                 <?php echo $affichages8["credit_disponible"]; ?> FCFA 
            </td>
        </tr>
    </table>
    <table style="vertical-align: bottom; text-align: center; margin-top: 5mm;">
        <tr>
            <td style="width: 50%;">
                <strong>Montant Engagé : </strong> <br/>
            </td>
            <td style="width: 50%;">
                 <?php echo $affichages8["montant_engage"]; ?> FCFA 
            </td>
        </tr>
    </table>
    <table style="vertical-align: bottom; text-align: center; margin-top: 5mm;">
        <tr>
            <td style="width: 50%;">
                <strong>Disponible aprés : </strong> <br/>
            </td>
            <td style="width: 50%;">
                 <?php echo $affichages8["disponible_apres"]; ?> FCFA 
            </td>
        </tr>
    </table>
    <p style="margin: 0; margin-top: 5mm; font-size: 12pt;">Ce bo, pour être valabe, doit comporter le vis ci-dessus prévu et le numéro d'engagement du CENTRE COMPTABLE du Ministére des Finances. <br/><br/> Il n'est exécutable que s'il est accompagné du titre de créance émis par le CENTRE COMPTABLE et sans lequel aucun réglement ne saurait possible. <br/><br/> Le fournisseur ne pourrait accepter qu'à ses risques et péeils toute commande qui serait passée sous une autre forme.</p>
    <table class="border"  style=" margin-top: 10mm;">
        <thead>
             <tr>
                <th colspan="2" style="text-align: center; width: 100%; letter-spacing: 10px; font-size: 15pt;">DESIGNATION DU FOURNISSEUR OU BENEFICIAIRE</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td style="width: 25%;"> <strong>Nif_Frs / Mle</strong></td>
                <td style="width: 75%;"> <?php echo $affichages8['nif_frs']; ?></td>
            </tr>
            <tr>
                <td style="width: 25%;"><strong>Nom</strong></td>
                <td style="width: 75%;"> <?php echo $affichages8['nom']; ?></td>
            </tr>
            <tr>
                <td style="width: 25%;"> <strong>Prénom</strong></td>
                <td style="width: 75%;"> <?php echo $affichages8['prenom']; ?></td>
            </tr>
            <tr>
                <td style="width: 25%;"><strong>Ville</strong></td>
                <td style="width: 75%;"> <?php echo $affichages8['ville']; ?></td>
            </tr>
            <tr>
                <td style="width: 25%;"><strong>Pays</strong></td>
                <td style="width: 75%;"> <?php echo $affichages8['pays']; ?></td>
            </tr>
            <tr>
                <td style="width: 25%;"><strong>Adresse</strong></td>
                <td style="width: 75%;"> <?php echo $affichages8['adresse']; ?></td>
            </tr>
        </tbody>
    </table>
    <table style="line-height: 7mm; margin-top: 10mm;">
        <tr>
            <td style="width: 34%; line-height: 7mm;">
                <strong>Présenté par : </strong> <br/>
            </td>
            <td style="width: 33%; line-height: 7mm;" >
                <strong> Vu et approuvé : </strong> <br/>
            </td>
            <td style="width: 33%; line-height: 7mm;" class="right1">
                <strong> Signature et Cachet </strong> <br/>
            </td>
        </tr>
    </table>
</page>
        <?php 
              }
         ?>
<?php 
$content=ob_get_clean();
require('html2pdf/html2pdf.class.php');
try{
$pdf= new HTML2PDF('P', 'A4', 'fr', 'true', 'UTF-8');
$pdf->pdf->SetDisplayMode('fullpage');
$pdf->writeHTML($content);
    ob_get_clean();
$pdf->Output('bon_engagement.pdf');
}
catch(HTML2PDF_exception $e){ 
die ($e);}
?>