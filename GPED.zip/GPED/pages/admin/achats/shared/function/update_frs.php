 <?php 
     session_start();  
?> 
<?php 
      // Connexion à la base de donnés
           include('connect.php');

      if (isset($_POST["nif_frs"]))
{
         $ccc=$_POST['nif_frs'];
         $nif_frs=$_POST["nif_frs"];
         $nom=$_POST["nom"];
         $prenom=$_POST["prenom"];
         $ville=$_POST["ville"];
         $pays=$_POST["pays"];
         $adresse=$_POST["adresse"];
     $req = $maConnexion->prepare("UPDATE fournisseur SET nif_frs=:nif_frs, nom=:nom, prenom=:prenom, ville=:ville, pays=:pays, adresse=:adresse WHERE nif_frs='$ccc'");
$req->execute(array(

    'nif_frs' => $nif_frs,

    'nom' => $nom,

    'prenom' => $prenom,

    'ville' => $ville,

    'pays' => $pays,

    'adresse' => $adresse   
    ));
      if($req->execute())
          {
            echo "<script> alert(\"La modification de cet enregistrement a été effectué avec succé!!!\")</script>";
            header('location: ../../liste_frs.php');
          }
      else
          {
            die('La modification a échoué, Réssayez à nouveau!!!.');
          }
     }
  ?>
  
