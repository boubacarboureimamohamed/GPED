<script language="JavaScript">
function surligne(champ, erreur)
{
   if(erreur)
      champ.style.borderColor = "#fba";
   else
      champ.style.borderColor = "#00ff36";
}
function verifmatricule(champ)

{
   var regex = /^[1-9][0-9]{1,4}\/T$/;
   if(!regex.test(champ.value))

   {

      surligne(champ, true);

      return false;

   }  
   

   else

   {

      surligne(champ, false);

      return true;

   }
  }
function verifnom(champ)

{
   var regex = /^[a-zA-Zéèçà][a-zéèçà]+([ -'\s][a-zA-Zéèçà][a-zéèçà]+)?$/;
   if(!regex.test(champ.value))

   {

      surligne(champ, true);

      return false;

   }  
   

   else

   {

      surligne(champ, false);

      return true;

   }
  }
function verifprenom(champ)

{
   var regex = /^[a-zA-Zéèçà][a-zéèçà]+([ -'\s][a-zA-Zéèçà][a-zéèçà]+)?$/;
   if(!regex.test(champ.value))

   {

      surligne(champ, true);

      return false;

   }  
   

   else

   {

      surligne(champ, false);

      return true;

   }
  }
  function verifville(champ)

{
   var regex = /^[a-zA-Zéèçà][a-zéèçà]+([ -'\s][a-zA-Zéèçà][a-zéèçà]+)?$/;
   if(!regex.test(champ.value))

   {

      surligne(champ, true);

      return false;

   }  
   

   else

   {

      surligne(champ, false);

      return true;

   }
  }
  function verifpays(champ)

{
   var regex = /^[a-zA-Zéèçà][a-zéèçà]+([ -'\s][a-zA-Zéèçà][a-zéèçà]+)?$/;
   if(!regex.test(champ.value))

   {

      surligne(champ, true);

      return false;

   }
   

   else

   {

      surligne(champ, false);

      return true;

   }
  }
  function verifForm(f)
{
   var matriculeOk = verifmatricule(f.matricule);
   var nomOk = verifnom(f.nom);
   var prenomOk = verifprenom(f.prenom);
   var villeOk = verifville(f.ville);
   var paysOk = verifpays(f.pays);
   if(matriculeOk && nomOk && prenomOk && villeOk && paysOk)
      return true;
   else
   {
      alert("Veuillez remplir correctement tous les champs");
      return false;
   }
}

</script>