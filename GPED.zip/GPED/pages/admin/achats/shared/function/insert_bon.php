<?php 
     session_start(); 
?>
<?php 
           // Connexion à la base de donnés
           include('connect.php');
           if(isset($_POST)){

           $stmt = $maConnexion->prepare('INSERT INTO bon_engagement (num_bon, ref_piece, code_imputation, credit_disponible, montant_engage, disponible_apres, quantite, montant_total, id_gestion, code_section, id_type, nif_frs, nature_depense, code_depense, code_reglement, code_service, code_programme, code_action, code_activite, code_tache, code_compte, date_bon) VALUES (:num_bon, :ref_piece, :code_imputation, :credit_disponible, :montant_engage, :disponible_apres, :quantite, :montant_total, :exercice, :ministere, :type_bon, :nif_frs, :nature_depense, :depense, :reglement, :service, :code_programme, :code_action, :code_activite, :code_tache, :code_compte, :date_bon)');
         
         //Définition des paramètres et Récupération des données du formulaire et affectation des valeurs aux paramètres de la requête
          var_dump($stmt->execute(array(
'num_bon'=>$_POST['num_bon'],
        'ref_piece'=>$_POST['ref_piece'],
     'code_imputation'=> $_POST['code_imputation'],
      'credit_disponible'=> $_POST['credit_disponible'],
       'montant_engage'=> $_POST['montant_engage_1'],
       'disponible_apres'=> $_POST['disponible_apres_1'],
        'quantite'=> $_POST['quantite'],
        'montant_total'=> $_POST['montant_total_1'],
        'exercice'=> $_POST['exercice'],
        'ministere'=> $_POST['ministere'],
        'type_bon'=> $_POST['type_bon'],
        'nif_frs'=> $_POST['nif_frs'],
        'nature_depense'=> $_POST['nature_depense'],
        'depense'=> $_POST['depense'],
        'reglement'=> $_POST['reglement'],
        'service'=> $_POST['service'],
        'code_programme'=> $_POST['code_programme'],
        'code_action'=> $_POST['code_action'],
        'code_activite'=> $_POST['code_activite'],
        'code_tache'=> $_POST['code_tache'],
        'code_compte'=> $_POST['code_compte'],
        'date_bon'=> $_POST['date_bon']
          )));
            
          $stmt = $maConnexion->prepare('INSERT INTO programme (code_programme, libelle_programme) VALUES (:code_programme, :libelle_programme)');
         
         //Définition des paramètres et Récupération des données du formulaire et affectation des valeurs aux paramètres de la requête
          var_dump($stmt->execute(array(
'code_programme'=>$_POST['code_programme'],
        'libelle_programme'=>$_POST['libelle_programme']

          )));

          $stmt = $maConnexion->prepare('INSERT INTO action (code_action, libelle_action, code_programme) VALUES (:code_action, :libelle_action, :code_programme)');
         
         //Définition des paramètres et Récupération des données du formulaire et affectation des valeurs aux paramètres de la requête
          var_dump($stmt->execute(array(
'code_action'=>$_POST['code_action'],
        'libelle_action'=>$_POST['libelle_action'],
        'code_programme'=>$_POST['code_programme']

          )));

          $stmt = $maConnexion->prepare('INSERT INTO activite (code_activite, libelle_activite, code_action) VALUES (:code_activite, :libelle_activite, :code_action)');
         
         //Définition des paramètres et Récupération des données du formulaire et affectation des valeurs aux paramètres de la requête
          var_dump($stmt->execute(array(
'code_activite'=>$_POST['code_activite'],
        'libelle_activite'=>$_POST['libelle_activite'],
        'code_action'=>$_POST['code_action']

          )));

          $stmt = $maConnexion->prepare('INSERT INTO tache (code_tache, libelle_tache, code_activite) VALUES (:code_tache, :libelle_tache, :code_activite)');
         
         //Définition des paramètres et Récupération des données du formulaire et affectation des valeurs aux paramètres de la requête
          var_dump($stmt->execute(array(
'code_tache'=>$_POST['code_tache'],
        'libelle_tache'=>$_POST['libelle_tache'],
        'code_activite'=>$_POST['code_activite']

          )));

          $stmt = $maConnexion->prepare('INSERT INTO compte (code_compte, intitule, pu) VALUES (:code_compte, :intitule, :pu)');
         
         //Définition des paramètres et Récupération des données du formulaire et affectation des valeurs aux paramètres de la requête
          var_dump($stmt->execute(array(
'code_compte'=>$_POST['code_compte'],
        'intitule'=>$_POST['intitule'],
        'pu'=>$_POST['pu']

          )));

          header('location:../../liste_engagement.php');
             die();
          }
      
?>