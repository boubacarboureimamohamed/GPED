 <?php 
     session_start(); 
?>
<?php
     // Connexion à la base de donnés
           include('connect.php');

      try 
     {
      //Récupération des données à supprimer
       $variable =isset($_GET['supression']) ? $_GET['supression'] : die('ERROR: Record nif_frs not found.');
       $query = "DELETE FROM fournisseur WHERE nif_frs = ?";
       $stmt = $maConnexion->prepare($query);
       $stmt->bindParam(1, $variable);
     
       if($stmt->execute())
         {
          header('Location: ../../liste_frs.php');
         }
       else
         {
          die('La suppresion a échoué, Réssayez à nouveau!!!.');
         }
      }
      // error
    catch(PDOException $exception)
         {
          die('ERROR: ' . $exception->getMessage());
         }
?>