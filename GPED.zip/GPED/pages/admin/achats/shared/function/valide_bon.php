<?php 
     session_start(); 
 ?>

 <?php  

     include('connect.php');

      if (isset($_POST["num_bon"]))

{
         $ccc=$_POST['num_bon'];
         $validate= 1;
         $date=$_POST['date'];
         
     $stmt = $maConnexion->prepare("UPDATE bon_engagement SET etat=:etat, date_valide=:date_valide WHERE num_bon='$ccc'");

      //Définition des paramètres et Récupération des données du formulaire et affectation des valeurs aux paramètres de la requête
          var_dump($stmt->execute(array(

    'etat' => $validate,

    'date_valide' => $date

    )));

          header('location:../../etat_engagement.php');

             die();
 }
  ?>
  

