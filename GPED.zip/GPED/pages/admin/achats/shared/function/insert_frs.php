<?php 
     session_start(); 
?>
<?php
     if (empty( $_SESSION['pseudo']) && empty($_SESSION['pass']))
         {
         header('location:../../index.php');
       }
     else if ( $_SESSION['pseudo']!="admin@db" && $_SESSION['pass']!="root_root")
         {
           header("location:../../index.php");
           session_destroy();
       }
?>
<?php 
           // Connexion à la base de donnés
           include('connect.php');
           if(isset($_POST)){
   try{
         //Prépation de la requête
        $stmt = $maConnexion->prepare('INSERT INTO fournisseur (nif_frs, nom, prenom, ville, pays, adresse) VALUES (:nif_frs, :nom, :prenom, :ville, :pays, :adresse)');
         
         //Définition des paramètres et Récupération des données du formulaire et affectation des valeurs aux paramètres de la requête
        $stmt->bindParam(':nif_frs', $_POST['nif_frs']);
        $stmt->bindParam(':nom', $_POST['nom']);
        $stmt->bindParam(':prenom', $_POST['prenom']);
        $stmt->bindParam(':ville', $_POST['ville']);
        $stmt->bindParam(':pays', $_POST['pays']);
        $stmt->bindParam(':adresse', $_POST['adresse']);
          
          // Exécution de la requête
         if($stmt->execute())
           {
                //Message de confirmation!!!
             echo "<script> alert(\"L'enregistrement a été effectué avec succé!!!\")</script>";
             header('location:../../liste_frs.php');
           }
        else
           {  
               //Message d'erreur!!!
             echo "<script> alert(\"L'enregistrement a échoué,  Veuillez saisir à nouveau!!!\")</script>";
           }

        
      }
      catch (PDOException $e)
          {
                 //ERROR!!!
             die('ERROR: ' . $exception->getMessage());
          }
          }
      
?>