<script language="JavaScript">
function surligne(champ, erreur)
{
   if(erreur)
      champ.style.borderColor = "#fba";
   else
      champ.style.borderColor = "#00ff36";
}
function verifimputation(champ)

{
   var regex = /^[1-9][0-9]{5,5}/;
   if(!regex.test(champ.value))

   {

      surligne(champ, true);

      return false;

   }  
   

   else

   {

      surligne(champ, false);

      return true;

   }
  }
function verifprogramme(champ)

{
   var regex = /^[1-9][0-9]{2,2}/;
   if(!regex.test(champ.value))

   {

      surligne(champ, true);

      return false;

   }  
   

   else

   {

      surligne(champ, false);

      return true;

   }
  }
function verifaction(champ)

{
   var regex = /^[1-9][0-9]{1,1}/;
   if(!regex.test(champ.value))

   {

      surligne(champ, true);

      return false;

   }  
   

   else

   {

      surligne(champ, false);

      return true;

   }
  }
function verifactivite(champ)

{
   var regex = /^[1-9][0-9]{1,1}/;
   if(!regex.test(champ.value))

   {

      surligne(champ, true);

      return false;

   }  
   

   else

   {

      surligne(champ, false);

      return true;

   }
  }
function veriftache(champ)

{
   var regex = /^[1-9][0-9]{1,1}/;
   if(!regex.test(champ.value))

   {

      surligne(champ, true);

      return false;

   }  
   

   else

   {

      surligne(champ, false);

      return true;

   }
  }
function verifcompte(champ)

{
   var regex = /^[1-9][0-9]{4,4}/;
   if(!regex.test(champ.value))

   {

      surligne(champ, true);

      return false;

   }  
   

   else

   {

      surligne(champ, false);

      return true;

   }
  }
  function veriflibelle(champ)

{
   var regex = /^[a-zA-Zéèçà][a-zéèçà]+([ -'\s][a-zA-Zéèçà][a-zéèçà]+)?$/;
   if(!regex.test(champ.value))

   {

      surligne(champ, true);

      return false;

   }  
   

   else

   {

      surligne(champ, false);

      return true;

   }
  }
  function verifpiece(champ)

{
   var regex = /^[1-9][0-9]{2,4}\/CT$/;
   if(!regex.test(champ.value))

   {

      surligne(champ, true);

      return false;

   }  
   

   else

   {

      surligne(champ, false);

      return true;

   }
  }
  function verifForm(f)
{;
   var imputationOk = verifimputation(f.imputation);
   var programmeOk = verifprogramme(f.programme);
   var actionOk = verifaction(f.Action);
   var activiteOk = verifactivite(f.activite);
   var tacheOk = veriftache(f.tache);
   var compteOk = verifcompte(f.compte);
   var libelleOk = veriflibelle(f.libelle);
   var pieceOk = verifpiece(f.piece);
   if(imputationOk && programmeOk && actionOk && activiteOk && tacheOk && compteOk && libelleOk && pieceOk)
      return true;
   else
   {
      alert("Veuillez remplir correctement tous les champs");
      return false;
   }
}

</script>