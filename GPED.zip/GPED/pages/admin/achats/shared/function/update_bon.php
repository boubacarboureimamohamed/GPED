<?php 
     session_start(); 
 ?>

 <?php  

     include('connect.php');

      if (isset($_POST["num_bon"]))
{
         $ccc=$_POST['num_bon'];
         $ref_piece=$_POST["ref_piece"];
         $code_imputation=$_POST["code_imputation"];
         $credit_disponible=$_POST["credit_disponible"];
         $montant_engage=$_POST["montant_engage"];
         $disponible_apres=$_POST["disponible_apres"];
         $quantite=$_POST["quantite"];
         $montant_total=$_POST["montant_total"];
         $nature_depense=$_POST["nature_depense"];
         $code_programme=$_POST["code_programme"];
         $pu=$_POST["pu"];
         $code_compte=$_POST["code_compte"];
         $intitule=$_POST["intitule"];
         
     $stmt = $maConnexion->prepare("UPDATE bon_engagement SET ref_piece=:ref_piece, code_imputation=:code_imputation, credit_disponible=:credit_disponible, montant_engage=:montant_engage, disponible_apres=:disponible_apres, quantite=:quantite, montant_total=:montant_total, nature_depense=:nature_depense, code_programme=:code_programme, code_compte=:code_compte WHERE num_bon='$ccc'");

      //Définition des paramètres et Récupération des données du formulaire et affectation des valeurs aux paramètres de la requête
          var_dump($stmt->execute(array(

    'ref_piece' => $ref_piece,

    'code_imputation' => $code_imputation,

    'credit_disponible' => $credit_disponible,
  
   'montant_engage' => $montant_engage,
  
   'disponible_apres' => $disponible_apres,
  
   'quantite' => $quantite,
  
   'montant_total' => $montant_total,
  
   'nature_depense' => $nature_depense,
  
   'code_programme' => $code_programme,
  
   'code_compte' => $code_compte

    )));

          $reponse = $maConnexion->query("SELECT code_compte FROM bon_engagement WHERE num_bon = '$ccc'");
          $compte = $reponse->fetch();
          $code_compte = $compte['code_compte'];
          $stmt = $maConnexion->prepare("UPDATE compte SET code_compte=:code_compte, intitule=:intitule, pu=:pu WHERE code_compte='$code_compte'");
          $stmt->execute(array(

    'pu' => $pu,
  
   'code_compte' => $code_compte,
  
   'intitule' => $intitule

      ));

          header('location:../../liste_engagement.php');

             die();
 }
  ?>
  

