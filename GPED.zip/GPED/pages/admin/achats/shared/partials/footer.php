
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="../../../js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="../../../js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="../../../js/metisMenu.min.js"></script> 

        <!-- Custom Theme JavaScript -->
        <script src="../../../js/startmin.js"></script>

        <!-- DataTables JavaScript -->
        <script src="../../../js/dataTables/jquery.dataTables.min.js"></script>
        <script src="../../../js/dataTables/dataTables.bootstrap.min.js"></script>
  
         <!-- Custom Modals  JavaScript -->
        <script  src="../../../js/modal/index.js"></script>
        <script  src="../../../js/modal/velocity.min.js"></script>
        <script  src="../../../js/modal/velocity.ui.min.js"></script>

        <!-- Page-Level Demo Scripts - Tables - Use for reference -->
        <script>
            $(document).ready(function() {
                $('#dataTables-example').DataTable({
                        responsive: true
                });

                     var qte = $('#quantite').val()
                     var pu = $('#pu').val()
                     var cd = $('#credit_disponible').val()

                $('#pu, #quantite, #credit_disponible').on('focusout', function(e) {
                    e.preventDefault()
                     qte = $('#quantite').val()
                     pu = $('#pu').val()
                     cd = $('#credit_disponible').val()
                    
                    console.log(qte)
                    console.log(pu)
                    console.log(cd)
                   var total = qte * pu
                   var da = cd - total
                
                 $('#montant_total').attr('value', total)
                 $('#montant_total_1').attr('value', total)
                 $('#montant_engage').attr('value', total)
                $('#montant_engage_1').attr('value', total)
                 $('#disponible_apres').attr('value', da)
                 $('#disponible_apres_1').attr('value', da)
                })
                
               
            });

            $('#refresh').on('click', function() {
                location.reload();
            });


        </script>

    </body>
</html> 
