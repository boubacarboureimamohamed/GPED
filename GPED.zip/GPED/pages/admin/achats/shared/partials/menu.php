<!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li>
                                <a href="#" style="text-align: center;" class="active"><i class="fa fa-home fa-fw"></i> Marchés et Commandes</a>
                                <li class="divider"></li>
                            </li>
                            <li>
                                <img src="../../../images/img4.png" alt="User Image" height="140px" width="250px">
                            </li>
                            <li class="active">
                                <a href="#"><i class="fa fa-indent fa-fw"></i> Marchés, Contrats, Proforma<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a class="active" href="#">Marchés</a>
                                    </li>
                                    <li>
                                        <a class="active" href="#">Contrats</a>
                                    </li>
                                    <li class="active">
                                        <a href="#">Proforma<span class="fa arrow"></span></a>
                                        <ul class="nav nav-third-level">
                                          <li>
                                            <a href="liste_engagement.php"" class="active"><i class="fa fa-folder-open fa-fw"></i> Engagement de dépense</a>
                                          </li>
                                        </ul>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li><li class="divider"></li>
                            <li class="active">
                                <a href="#"><i class="fa fa-bookmark-o fa-fw"></i> Fournisseurs<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="liste_frs.php" class="active"><i class="fa fa-list-ul fa-fw"></i> Liste des fournisseurs</a>
                                    </li>
                                    <li>
                                        <a class="active" href="#">Commandes aux fournisseurs</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>              