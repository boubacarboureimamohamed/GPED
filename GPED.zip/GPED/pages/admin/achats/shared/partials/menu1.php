<!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li>
                                <a href="#" style="text-align: center;" class="active"><i class="fa fa-home fa-fw"></i> Engagement Dépenses</a>
                                <li class="divider"></li>
                            </li>
                            <li>
                                <img src="../../../images/img2.png" alt="User Image" height="230px" width="250px">
                            </li><li class="divider"></li>
                            <li>
                                <a href="liste_engagement.php" class="active"><i class="fa fa-list-ul fa-fw"></i> Liste des bons</a>
                            </li>
                            <li>
                                <a href="etat_engagement.php" class="active"><i class="fa fa-bar-chart fa-fw"></i> Etat des bons</a>
                            </li>
                            <li>
                                <a href="titre_creance.php" class="active"><i class="fa fa-credit-card fa-fw"></i> Etablir des créancess</a>
                            </li><li class="divider"></li>
                            <li>
                                <a href="index1.php" class="active"><i class="fa fa-indent fa-fw"></i> Marchés et Commandes</a>
                                <li class="divider"></li>
                            </li>
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>              