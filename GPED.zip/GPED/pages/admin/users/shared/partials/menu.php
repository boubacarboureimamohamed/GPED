<!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li>
                                <a class="active" href="#" style="text-align: center;"><i class="fa fa-user fa-fw"></i>Utilisateurs</a>
                                <li class="divider"></li>
                            </li>
                            <li>
                                <img src="../../../images/user3.png" alt="User Image" height="250px" width="250px"><li class="divider"></li>
                            </li>
                            <li>
                                <a href="index2.php"><i class="fa fa-list-ul fa-fw"></i> Liste des utilisateurs</a>
                                <li class="divider"></li>
                            </li>
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>