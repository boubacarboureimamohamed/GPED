<?php 
     session_start(); 
?> 
<?php
     include('partials/header.php');
?>
            
<?php
     include('partials/menu.php');
?>
     
     <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="page-header" style="text-align: center;"> <marquee><b>GESTION DES PROPOSITIONS D'ENGAGEMENT DE DEPENSE DANS UN SERVICE FINANCIER MINISTERIEL : CAS DU MINISTERE DES FINANCES</b></marquee></h2>  
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12" style="text-align: center;">
                             <img src="../../images/logo1.png" alt="Images d'accueil" width="750px" height="470px">
                        </div>
                    </div>
                </div> 
            </div>   

<?php
     include('partials/footer.php');
?>