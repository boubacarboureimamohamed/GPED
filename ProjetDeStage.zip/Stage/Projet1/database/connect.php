<?php


try

    {
       $maConnexion = new PDO('mysql:host=localhost;dbname=mydatabase;charset=utf8', 'root', '');
       echo "Connexion à la base des données établie";

    }

catch (Exception $e)


    {
      echo "Connexion à la base des données non établie, réssayez à nouveau!!!";

       die('Erreur : ' . $e->getMessage());
    }


?>