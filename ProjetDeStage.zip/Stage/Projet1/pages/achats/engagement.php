<?php
     include('shared/partials/header.php');
?>
            
<?php
     include('shared/partials/menu.php');
?> 

<!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="page-header">Liste des bons d'engagements</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                            <tr>
                                                <th>NIF_Frs</th>
                                                <th>Nom</th>
                                                <th>Prénom</th>
                                                <th>Ville</th>
                                                <th>Pays</th>
                                                <th>Adresse</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="odd gradeX">
                                                <td>Trident</td>
                                                <td>Internet Explorer 4.0</td>
                                                <td>Win 95+</td>
                                                <td>Win 95+</td>
                                                <td class="center">4</td>
                                                <td class="center">X</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="gradeA">
                                                <td>Gecko</td>
                                                <td>Netscape Navigator 9</td>
                                                <td>Win 98+ / OSX.2+</td>
                                                <td>Win 95+</td>
                                                <td class="center">1.8</td>
                                                <td class="center">A</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->

<?php
     include('shared/partials/footer.php');
?>