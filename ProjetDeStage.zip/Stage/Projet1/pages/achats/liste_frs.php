<?php
     include('shared/partials/header.php');
?>
            
<?php
     include('shared/partials/menu.php');
?> 


            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="page-header">Liste des fournisseurs</h2>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                                <div class="dataTable_wrapper">
                                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <div id="detail" class="modal" data-easein="slideUpIn" tabindex="-1" role="dialog" aria-labelledby="costumModaLlabeL" aria-hidden="true">
                                        <thead>
                                            <tr>
                                                <th>NIF_Frs</th>
                                                <th>Nom</th>
                                                <th>Prénom</th>
                                                <th>Ville</th>
                                                <th>Pays</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="odd gradeX">
                                                <td>Trident</td>
                                                <td>Internet Explorer 4.0</td>
                                                <td>Win 95+</td>
                                                <td class="center">4</td>
                                                <td class="center">X</td>
                                                <td>
                                                    <a role="button" data-toggle="modal" data-target="#detail"><i class="btn btn-info fa fa-eye"></i></a>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="even gradeC">
                                                <td>Trident</td>
                                                <td>Internet Explorer 5.0</td>
                                                <td>Win 95+</td>
                                                <td class="center">5</td>
                                                <td class="center">C</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="odd gradeA">
                                                <td>Trident</td>
                                                <td>Internet Explorer 5.5</td>
                                                <td>Win 95+</td>
                                                <td class="center">5.5</td>
                                                <td class="center">A</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="even gradeA">
                                                <td>Trident</td>
                                                <td>Internet Explorer 6</td>
                                                <td>Win 98+</td>
                                                <td class="center">6</td>
                                                <td class="center">A</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="odd gradeA">
                                                <td>Trident</td>
                                                <td>Internet Explorer 7</td>
                                                <td>Win XP SP2+</td>
                                                <td class="center">7</td>
                                                <td class="center">A</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="even gradeA">
                                                <td>Trident</td>
                                                <td>AOL browser (AOL desktop)</td>
                                                <td>Win XP</td>
                                                <td class="center">6</td>
                                                <td class="center">A</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="gradeA">
                                                <td>Gecko</td>
                                                <td>Firefox 1.0</td>
                                                <td>Win 98+ / OSX.2+</td>
                                                <td class="center">1.7</td>
                                                <td class="center">A</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="gradeA">
                                                <td>Gecko</td>
                                                <td>Firefox 1.5</td>
                                                <td>Win 98+ / OSX.2+</td>
                                                <td class="center">1.8</td>
                                                <td class="center">A</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="gradeA">
                                                <td>Gecko</td>
                                                <td>Firefox 2.0</td>
                                                <td>Win 98+ / OSX.2+</td>
                                                <td class="center">1.8</td>
                                                <td class="center">A</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="gradeA">
                                                <td>Gecko</td>
                                                <td>Firefox 3.0</td>
                                                <td>Win 2k+ / OSX.3+</td>
                                                <td class="center">1.9</td>
                                                <td class="center">A</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="gradeA">
                                                <td>Gecko</td>
                                                <td>Camino 1.0</td>
                                                <td>OSX.2+</td>
                                                <td class="center">1.8</td>
                                                <td class="center">A</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="gradeA">
                                                <td>Gecko</td>
                                                <td>Camino 1.5</td>
                                                <td>OSX.3+</td>
                                                <td class="center">1.8</td>
                                                <td class="center">A</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="gradeA">
                                                <td>Gecko</td>
                                                <td>Netscape 7.2</td>
                                                <td>Win 95+ / Mac OS 8.6-9.2</td>
                                                <td class="center">1.7</td>
                                                <td class="center">A</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="gradeA">
                                                <td>Gecko</td>
                                                <td>Netscape Browser 8</td>
                                                <td>Win 98SE+</td>
                                                <td class="center">1.7</td>
                                                <td class="center">A</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="gradeA">
                                                <td>Gecko</td>
                                                <td>Netscape Navigator 9</td>
                                                <td>Win 98+ / OSX.2+</td>
                                                <td class="center">1.8</td>
                                                <td class="center">A</td>
                                                <td>
                                                    <button class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                             </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->

<?php
     include('shared/partials/footer.php');
?>