<?php
     include('partials/header.php');
?>
            
<?php
     include('partials/menu.php');
?>
     
     <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="page-header">Bienvenue Administrateur</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            
                        </div>
                    </div>
                </div>
            </div>   

<?php
     include('partials/footer.php');
?>