<?php
     include('shared/partials/header.php');
?>
            
<?php
     include('shared/partials/menu.php');
?>
     
     <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="page-header">Liste des utilisateurs</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            
                        </div>
                    </div>
                </div>
            </div>   

<?php
     include('shared/partials/footer.php');
?>