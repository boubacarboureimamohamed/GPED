-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  jeu. 09 août 2018 à 13:24
-- Version du serveur :  10.1.29-MariaDB
-- Version de PHP :  7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `mydatabase`
--

-- --------------------------------------------------------

--
-- Structure de la table `action`
--

CREATE TABLE `action` (
  `code_action` int(2) NOT NULL,
  `libelle_action` varchar(30) DEFAULT NULL,
  `code_programme` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `activite`
--

CREATE TABLE `activite` (
  `code_activite` int(2) NOT NULL,
  `libelle_activite` varchar(30) DEFAULT NULL,
  `code_action` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `avoir`
--

CREATE TABLE `avoir` (
  `id_detail` int(3) NOT NULL,
  `num_bon` int(5) NOT NULL,
  `quantite` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `bon_engagement`
--

CREATE TABLE `bon_engagement` (
  `num_bon` int(5) NOT NULL,
  `date_bon` date DEFAULT NULL,
  `ref_piece` varchar(30) DEFAULT NULL,
  `code_imputation` int(6) DEFAULT NULL,
  `nif_frs` varchar(10) DEFAULT NULL,
  `id_type` int(5) DEFAULT NULL,
  `code_compte` int(6) DEFAULT NULL,
  `code_section` int(2) DEFAULT NULL,
  `code_depense` int(2) DEFAULT NULL,
  `code_categorie` int(1) DEFAULT NULL,
  `code_programme` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `code_categorie` int(1) NOT NULL,
  `libelle_categorie` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compte`
--

CREATE TABLE `compte` (
  `code_compte` int(6) NOT NULL,
  `intitule` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `depense`
--

CREATE TABLE `depense` (
  `code_depense` int(2) NOT NULL,
  `libelle_depense` varchar(30) DEFAULT NULL,
  `nature_depense` char(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `detail`
--

CREATE TABLE `detail` (
  `id_detail` int(3) NOT NULL,
  `detail` varchar(30) DEFAULT NULL,
  `pu` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `etat_bon_engagement`
--

CREATE TABLE `etat_bon_engagement` (
  `id_etat` int(3) NOT NULL,
  `etat` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `fournisseur`
--

CREATE TABLE `fournisseur` (
  `nif_frs` varchar(10) NOT NULL,
  `nom` char(30) DEFAULT NULL,
  `prenom` char(15) DEFAULT NULL,
  `ville` char(10) DEFAULT NULL,
  `pays` char(10) DEFAULT NULL,
  `adresse` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `gerer`
--

CREATE TABLE `gerer` (
  `code_compte` int(6) NOT NULL,
  `id_gestion` int(3) NOT NULL,
  `montant_engage` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `gestion`
--

CREATE TABLE `gestion` (
  `id_gestion` int(3) NOT NULL,
  `gestion` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `posseder`
--

CREATE TABLE `posseder` (
  `id_etat` int(3) NOT NULL,
  `num_bon` int(5) NOT NULL,
  `date_etat` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `programme`
--

CREATE TABLE `programme` (
  `code_programme` int(3) NOT NULL,
  `libelle_programme` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `section`
--

CREATE TABLE `section` (
  `code_section` int(2) NOT NULL,
  `libelle_section` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `service`
--

CREATE TABLE `service` (
  `code_service` int(2) NOT NULL,
  `libelle_service` varchar(30) DEFAULT NULL,
  `code_section` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `tache`
--

CREATE TABLE `tache` (
  `code_tache` int(2) NOT NULL,
  `libelle_tache` varchar(30) DEFAULT NULL,
  `code_activite` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `type_bon_engagement`
--

CREATE TABLE `type_bon_engagement` (
  `id_type` int(5) NOT NULL,
  `type` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id_user` int(3) NOT NULL,
  `username` varchar(15) DEFAULT NULL,
  `password` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `action`
--
ALTER TABLE `action`
  ADD PRIMARY KEY (`code_action`),
  ADD KEY `code_programme` (`code_programme`);

--
-- Index pour la table `activite`
--
ALTER TABLE `activite`
  ADD PRIMARY KEY (`code_activite`),
  ADD KEY `code_action` (`code_action`);

--
-- Index pour la table `avoir`
--
ALTER TABLE `avoir`
  ADD PRIMARY KEY (`id_detail`,`num_bon`);

--
-- Index pour la table `bon_engagement`
--
ALTER TABLE `bon_engagement`
  ADD PRIMARY KEY (`num_bon`),
  ADD KEY `code_compte` (`code_compte`),
  ADD KEY `code_depense` (`code_depense`),
  ADD KEY `id_type` (`id_type`),
  ADD KEY `code_categorie` (`code_categorie`),
  ADD KEY `code_section` (`code_section`),
  ADD KEY `code_programme` (`code_programme`),
  ADD KEY `nif_frs` (`nif_frs`);

--
-- Index pour la table `categorie`
--
ALTER TABLE `categorie`
  ADD PRIMARY KEY (`code_categorie`);

--
-- Index pour la table `compte`
--
ALTER TABLE `compte`
  ADD PRIMARY KEY (`code_compte`);

--
-- Index pour la table `depense`
--
ALTER TABLE `depense`
  ADD PRIMARY KEY (`code_depense`);

--
-- Index pour la table `detail`
--
ALTER TABLE `detail`
  ADD PRIMARY KEY (`id_detail`);

--
-- Index pour la table `etat_bon_engagement`
--
ALTER TABLE `etat_bon_engagement`
  ADD PRIMARY KEY (`id_etat`);

--
-- Index pour la table `fournisseur`
--
ALTER TABLE `fournisseur`
  ADD PRIMARY KEY (`nif_frs`);

--
-- Index pour la table `gerer`
--
ALTER TABLE `gerer`
  ADD PRIMARY KEY (`code_compte`,`id_gestion`);

--
-- Index pour la table `gestion`
--
ALTER TABLE `gestion`
  ADD PRIMARY KEY (`id_gestion`);

--
-- Index pour la table `posseder`
--
ALTER TABLE `posseder`
  ADD PRIMARY KEY (`id_etat`,`num_bon`);

--
-- Index pour la table `programme`
--
ALTER TABLE `programme`
  ADD PRIMARY KEY (`code_programme`);

--
-- Index pour la table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`code_section`);

--
-- Index pour la table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`code_service`),
  ADD KEY `fk1` (`code_section`);

--
-- Index pour la table `tache`
--
ALTER TABLE `tache`
  ADD PRIMARY KEY (`code_tache`),
  ADD KEY `code_activite` (`code_activite`);

--
-- Index pour la table `type_bon_engagement`
--
ALTER TABLE `type_bon_engagement`
  ADD PRIMARY KEY (`id_type`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(3) NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `action`
--
ALTER TABLE `action`
  ADD CONSTRAINT `action_ibfk_1` FOREIGN KEY (`code_programme`) REFERENCES `programme` (`code_programme`);

--
-- Contraintes pour la table `activite`
--
ALTER TABLE `activite`
  ADD CONSTRAINT `activite_ibfk_1` FOREIGN KEY (`code_action`) REFERENCES `action` (`code_action`);

--
-- Contraintes pour la table `bon_engagement`
--
ALTER TABLE `bon_engagement`
  ADD CONSTRAINT `bon_engagement_ibfk_1` FOREIGN KEY (`code_compte`) REFERENCES `compte` (`code_compte`),
  ADD CONSTRAINT `bon_engagement_ibfk_2` FOREIGN KEY (`code_depense`) REFERENCES `depense` (`code_depense`),
  ADD CONSTRAINT `bon_engagement_ibfk_3` FOREIGN KEY (`id_type`) REFERENCES `type_bon_engagement` (`id_type`),
  ADD CONSTRAINT `bon_engagement_ibfk_4` FOREIGN KEY (`code_categorie`) REFERENCES `categorie` (`code_categorie`),
  ADD CONSTRAINT `bon_engagement_ibfk_5` FOREIGN KEY (`code_section`) REFERENCES `section` (`code_section`),
  ADD CONSTRAINT `bon_engagement_ibfk_6` FOREIGN KEY (`code_programme`) REFERENCES `programme` (`code_programme`),
  ADD CONSTRAINT `bon_engagement_ibfk_7` FOREIGN KEY (`nif_frs`) REFERENCES `fournisseur` (`nif_frs`);

--
-- Contraintes pour la table `service`
--
ALTER TABLE `service`
  ADD CONSTRAINT `fk1` FOREIGN KEY (`code_section`) REFERENCES `section` (`code_section`);

--
-- Contraintes pour la table `tache`
--
ALTER TABLE `tache`
  ADD CONSTRAINT `tache_ibfk_1` FOREIGN KEY (`code_activite`) REFERENCES `activite` (`code_activite`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
