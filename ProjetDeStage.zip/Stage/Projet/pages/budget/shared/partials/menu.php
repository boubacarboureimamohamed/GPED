<!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li>
                                <a href="index2.php" style="text-align: center;"><i class="fa fa-home fa-fw"></i> Budget</a>
                                <li class="divider"></li>
                            </li>
                            <li class="active">
                                <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Plan budgétaire<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li class="active">
                                        <a class="active" href="#">Nomenclature Budgétaire<span class="fa arrow"></span></a>
                                        <ul class="nav nav-third-level">
                                          <li>
                                            <a href="#">Dépenses</a>
                                          </li>
                                          <li>
                                            <a href="#">Recttes</a>
                                          </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a class="active" href="#">Validation budgétaire</a>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li><li class="divider"></li>
                            <li class="active">
                                <a href="#"><i class="fa fa-files-o fa-fw"></i> Opérations sur budget<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a class="active" href="achats/liste_frs.php">Révisions budgétaires</a>
                                    </li>
                                    <li>
                                        <a class="active" href="#">Transferts budgétaires</a>
                                    </li>
                                    <li>
                                        <a class="active" href="#">Engagements budgétaires</a>
                                    </li>
                                    <li>
                                        <a class="active" href="#">Liquidations</a>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>