<?php
     include('shared/partials/header.php');
?>
  
<?php
     include('shared/partials/menu.php');
?>

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="row">
                   <div class="col-lg-12">
                     <h2 class="page-header" style="text-align: center;">Facturations</h2>
                   </div>
                </div>
                <div class="row">
                   <div class="col-lg-12">

                   </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /#page-wrapper -->

<?php
     include('shared/partials/footer.php');
?>
