<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Startmin - Bootstrap Admin Theme</title>

        <!-- Bootstrap Core CSS -->
        <link href="../../css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="../../css/metisMenu.min.css" rel="stylesheet">

        <!-- Social Buttons CSS -->
        <link href="../../css/bootstrap-social.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="../../css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="../../css/font-awesome.min.css" rel="stylesheet" type="text/css">

        <!-- Custom Modals -->

        <link href="../../css/bootstrap-modal/css/bootstrap-modal-bs3patch.css" rel="stylesheet" type="text/css" />
        <link href="../../css/bootstrap-modal/css/bootstrap-modal.css" rel="stylesheet" type="text/css" />
    </head>
    <body>

    <div id="wrapper">
                  <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                    <a class="navbar-brand" href="#"><b>LOGO</b></a>
                </div>

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <ul class="nav navbar-nav navbar-left navbar-top-links">
                    <li><a href="#" style="margin-left: 65px;"><i class="fa fa-home fa-fw"></i> <b>B</b>udget <b>P</b>rogramme</a></li>
                </ul>

                <ul class="nav navbar-right navbar-top-links">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-fire fa-fw"></i> OPTIONS <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li><a href="../../pages/accueil.php"><i class="fa fa-reply-all fa-fw"></i> Accueil</a>
                            </li>
                            <li class="divider"></li>
                            <li><a href="#"><i class="fa fa-refresh fa-fw"></i> Actualiser</a>
                            </li>
                            <li class="divider"></li>
                            <li><a href="../../index.php"><i class="fa fa-sign-out fa-fw"></i> Deconnexion</a>
                            </li>
                        </ul>
                    </li>
                </ul>