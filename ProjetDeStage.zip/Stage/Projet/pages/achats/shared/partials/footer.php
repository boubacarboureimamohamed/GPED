</div>
<div id="static1" class="modal fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
  <form method="post" id="user_form" enctype="multipart/form-data">
   <div class="modal-content">
    <div class="modal-header" align="center">
     <button type="button" class="close" data-dismiss="modal">&times;</button>
     <h4 class="modal-title">Add a new bon</h4>
    </div>
    <div class="modal-body">
     <label>Enter First Name</label>
     <input type="text" name="first_name" id="first_name" class="form-control" />
     <br />
     <label>Enter Last Name</label>
     <input type="text" name="nom" id="nom" class="form-control" />
    </div>
    <div class="modal-footer" >
     <input type="submit" name="action" id="action" class="btn btn-success" value="Add"/>
     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
   </div>
  </form>
</div>
<div id="static2" class="modal fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
  <form method="post" id="user_form" enctype="multipart/form-data">
   <div class="modal-content">
    <div class="modal-header" align="center">
     <button type="button" class="close" data-dismiss="modal">&times;</button>
     <h4 class="modal-title">Updated Bon</h4>
    </div>
    <div class="modal-body">
     
    </div>
    <div class="modal-footer" >
     <input type="submit" name="action" id="action" class="btn btn-success" value="Save"/>
     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
   </div>
  </form>
</div>
<div id="static4" class="modal fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
  <form method="post" id="user_form" enctype="multipart/form-data">
   <div class="modal-content">
    <div class="modal-header" align="center">
     <button type="button" class="close" data-dismiss="modal">&times;</button>
     <h4 class="modal-title">Updated Fournisseur</h4>
    </div>
    <div class="modal-body">

    </div>
    <div class="modal-footer" >
     <input type="submit" name="action" id="action" class="btn btn-success" value="Save"/>
     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
   </div>
  </form>
</div>
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="../../js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="../../js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="../../js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="../../js/startmin.js"></script>

        <!-- DataTables JavaScript -->
        <script src="../../js/dataTables/jquery.dataTables.min.js"></script>
        <script src="../../js/dataTables/dataTables.bootstrap.min.js"></script>

        <script src="../../css/bootstrap-modal/js/bootstrap-modalmanager.js" type="text/javascript"></script>
        <script src="../../css/bootstrap-modal/js/bootstrap-modal.js" type="text/javascript"></script>
        <script src="../../css/bootstrap-modal/js/ui-extended-modals.min.js" type="text/javascript"></script>

        <!-- Page-Level Demo Scripts - Tables - Use for reference -->
        <script>
            $(document).ready(function() {
                $('#dataTables-example').DataTable({
                        responsive: true
                });
            });
        </script>

    </body>
</html> 
