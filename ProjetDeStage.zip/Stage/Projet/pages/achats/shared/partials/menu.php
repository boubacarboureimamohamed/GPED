<!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li>
                                <a href="index1.php" style="text-align: center;" class="active"><i class="fa fa-home fa-fw"></i> Marchés et Commandes</a>
                                <li class="divider"></li>
                            </li>
                            <li class="active">
                                <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Marchés, Contrats, Proforma<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a class="active" href="#">Marchés</a>
                                    </li>
                                    <li>
                                        <a class="active" href="#">Contrats</a>
                                    </li>
                                    <li>
                                        <a class="active" href="#">Proforma</a>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li><li class="divider"></li>
                            <li class="active">
                                <a href="#"><i class="fa fa-files-o fa-fw"></i> Fournisseurs<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    <li>
                                        <a href="liste_frs.php" class="active">Liste des fournisseurs</a>
                                    </li>
                                    <li>
                                        <a class="active" href="#">Commandes aux fournisseurs</a>
                                    </li>
                                </ul>
                                <!-- /.nav-second-level -->
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="liste_engagement.php"><i class="fa fa-edit fa-fw"></i> Engagement dépenses</a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>              