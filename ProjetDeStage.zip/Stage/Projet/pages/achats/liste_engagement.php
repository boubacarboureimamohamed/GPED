<?php
     include('shared/partials/header.php');
?>
            
<?php
     include('shared/partials/menu.php');
?> 

<!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="page-header">Liste des bons d'engagements</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="dataTable_wrapper">
                                <div align="right">
                                   <a href="engagement.php"><button type="button" class="btn btn-success"><i class="fa fa-plus fa-fw"></i> New</button></a>
                                </div>
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                            <tr>
                                                <th>Bon N°</th>
                                                <th>Type Bon</th>
                                                <th>Imputation</th>
                                                <th>Ministére</th>
                                                <th>Service</th>
                                                <th>Fournisseur</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr class="odd gradeX">
                                                <td>4</td>
                                                <td>Internet Explorer 4.0</td>
                                                <td>Win 95+</td>
                                                <td>Win 95+</td>
                                                <td class="center">Trident</td>
                                                <td class="center">Jhon</td>
                                                <td>
                                                    <button type="button" id="add_button" data-toggle="modal" data-target="#static2" class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="gradeA">
                                                <td>1.8</td>
                                                <td>Netscape Navigator 9</td>
                                                <td>Win 98+ / OSX.2+</td>
                                                <td>Win 95+</td>
                                                <td class="center">Gecko</td>
                                                <td class="center">Paul</td>
                                                <td>
                                                    <button type="button" id="add_button" data-toggle="modal" data-target="#static2" class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="odd gradeX">
                                                <td>4</td>
                                                <td>Internet Explorer 4.0</td>
                                                <td>Win 95+</td>
                                                <td>Win 95+</td>
                                                <td class="center">Trident</td>
                                                <td class="center">Jhon</td>
                                                <td>
                                                    <button type="button" id="add_button" data-toggle="modal" data-target="#static2" class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="gradeA">
                                                <td>1.8</td>
                                                <td>Netscape Navigator 9</td>
                                                <td>Win 98+ / OSX.2+</td>
                                                <td>Win 95+</td>
                                                <td class="center">Gecko</td>
                                                <td class="center">Paul</td>
                                                <td>
                                                    <button type="button" id="add_button" data-toggle="modal" data-target="#static2" class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                            <tr class="gradeA">
                                                <td>1.8</td>
                                                <td>Netscape Navigator 9</td>
                                                <td>Win 98+ / OSX.2+</td>
                                                <td>Win 95+</td>
                                                <td class="center">Gecko</td>
                                                <td class="center">Paul</td>
                                                <td>
                                                    <button type="button" id="add_button" data-toggle="modal" data-target="#static2" class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <button class="btn btn-danger"><i class="fa fa-trash-o fa-fw"></i></button>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->
<?php
     include('shared/partials/footer.php');
?>