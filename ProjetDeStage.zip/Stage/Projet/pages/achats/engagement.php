<?php
     include('shared/partials/header.php');
?>
            
<?php
     include('shared/partials/menu.php');
?> 

<!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h3 class="page-header">
                            NOUVEAU BON D'ENGAGEMENT</h3>
                        </div>
                    </div>
                    <div class="row">
                         <div class="col-lg-12">
                         <div class="panel panel-default">
                            <div class="panel-heading" style="text-align: center;">
                                BON D'ENGAGEMENT-ORIGINAL
                            </div>
                            <div class="panel-body">
                                <form action="#" method="post">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">Dépense :</label>
                                            <div class="col-md-8">
                                               <select class="form-control input-sm">
                                                    <option>Quel Dépense................?</option>
                                                    <option>Dépense Eventuelle (1)</option>
                                                    <option>Marché Dépense Permanente (2)</option>
                                                    <option>Réservation Blocage (30)</option>
                                                    <option>Délégation De Crédits</option>
                                               </select>
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">Réglement :</label>
                                            <div class="col-md-8">
                                               <select class="form-control input-sm">
                                                    <option>Quel Réglement.............?</option>
                                                    <option>Réglement Unique (1)</option>
                                                    <option>Réglements Fractionnés ou Echelonnés (2)</option>
                                                    <option>Réglements Immédiat (0)</option>
                                               </select>
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">Nature de la dépense :</label>
                                               <div class="col-md-8">
                                                     <textarea class="form-control" rows="1"></textarea> 
                                              </div>
                                        </div><br><br>
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">Réf - Piéces justificatives :</label>
                                               <div class="col-md-8">
                                                     <textarea class="form-control" rows="1"></textarea> 
                                              </div>
                                        </div><br><br>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Programme:</label>
                                            <div class="col-md-3">
                                               <input type="text" class="form-control input-sm" placeholder="Code">
                                            </div>
                                            <div class="col-md-6">
                                               <input type="text" class="form-control input-sm" placeholder="Libellé">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Action  :</label>
                                            <div class="col-md-3">
                                               <input type="text" class="form-control input-sm" placeholder="Code">
                                            </div>
                                            <div class="col-md-6">
                                               <input type="text" class="form-control input-sm" placeholder="Libellé">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Activité :</label>
                                            <div class="col-md-3">
                                               <input type="text" class="form-control input-sm" placeholder="Code">
                                            </div>
                                            <div class="col-md-6">
                                               <input type="text" class="form-control input-sm" placeholder="Libellé">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Tâche :</label>
                                            <div class="col-md-3">
                                               <input type="text" class="form-control input-sm" placeholder="Code">
                                            </div>
                                            <div class="col-md-6">
                                               <input type="text" class="form-control input-sm" placeholder="Libellé">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Compte :</label>
                                            <div class="col-md-3">
                                               <input type="text" class="form-control input-sm" placeholder="Code">
                                            </div>
                                            <div class="col-md-6">
                                               <input type="text" class="form-control input-sm" placeholder="Libellé">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-3 control-label">Quntité :</label>
                                            <div class="col-md-3">
                                               <input type="text" class="form-control input-sm" placeholder="Quntité.?">
                                            </div>
                                            <label class="col-md-2 control-label">Prix_U:</label>
                                            <div class="col-md-4">
                                               <input type="text" class="form-control input-sm" placeholder="Quel prix........?">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-6 control-label">Montant Total :</label>
                                            <div class="col-md-6">
                                               <input type="text" class="form-control input-sm" placeholder="Quel montant....................?">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="col-md-8 control-label"><h4>REPUBLIQUE DU NIGER</h4></label>
                                            <div class="col-md-4">
                                               <select class="form-control input-sm">
                                                    <option value="">--gestion--</option>
                                                    <option> 2016 </option>
                                                    <option> 2017</option>
                                                    <option> 2018</option>
                                               </select>
                                            </div>
                                        </div><br><br>
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">MINISTERE :</label>
                                            <div class="col-md-8">
                                               <select class="form-control input-sm">
                                                    <option>Quel Ministére..............?</option>
                                                    <option>Ministére des Finances</option>
                                                    <option>Ministére de la Santé</option>
                                                    <option>Ministére de la Justice</option>
                                                    <option>Ministére de l'éducation</option>
                                                    <option>Ministére de l'enseignement supérieur</option>
                                               </select>
                                            </div>
                                        </div><br><br>
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">SERVICE EMETTEUR :</label>
                                            <div class="col-md-8">
                                               <select class="form-control input-sm">
                                                    <option>Option 1</option>
                                                    <option>Option 2</option>
                                                    <option>Option 3</option>
                                                    <option>Option 4</option>
                                                    <option>Option 5</option>
                                               </select>
                                            </div>
                                        </div><br><br>
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">Imputation :</label>
                                            <div class="col-md-8">
                                                 <input type="text" class="form-control input-sm" placeholder="Code Imputation"> 
                                            </div>
                                        </div><br><br>
                                        <div class="form-group">
                                            <label class="col-md-6 control-label">Bon  N° :</label>
                                            <div class="col-md-6">
                                               <input type="text" class="form-control input-sm" placeholder="Numéro">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-6 control-label">Type bon :</label>
                                            <div class="col-md-6">
                                               <select class="form-control input-sm">
                                                    <option value="">Quel type de bon..........?</option>
                                                    <option>Ordinaire</option>
                                                    <option>Marché</option>
                                               </select>
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-6 control-label">Crédits disponibles :</label>
                                            <div class="col-md-6">
                                               <input type="text" class="form-control input-sm" placeholder="Quel montant.................?">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-6 control-label">Montant engagé :</label>
                                            <div class="col-md-6">
                                               <input type="text" class="form-control input-sm" placeholder="Quel montant.................?">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-6 control-label">Disponible aprés :</label>
                                            <div class="col-md-6">
                                               <input type="text" class="form-control input-sm" placeholder="Quel montant.................?">
                                            </div>
                                        </div><br>
                                        <div class="form-group">
                                            <label class="col-md-6 control-label">Matricule / NIF_Frs :</label>
                                            <div class="col-md-6">
                                                 <input type="text" class="form-control input-sm" placeholder="Code Imputation">
                                            </div>
                                        </div><br>
                                    </div><br>
                                    <div class="form-group">
                                            <label class="col-md-2 control-label">Nom :</label>
                                            <div class="col-md-4">
                                                 <input type="text" class="form-control input-sm" placeholder="Code Imputation">
                                            </div>
                                            <label class="col-md-2 control-label">Prénom :</label>
                                            <div class="col-md-4">
                                                 <input type="text" class="form-control input-sm" placeholder="Code Imputation">
                                            </div><br><br><br><br>
                                        </div><br><br><br><br>
                                    <div class="form-group">
                                            <label class="col-md-2 control-label">Ville :</label>
                                            <div class="col-md-4">
                                                 <input type="text" class="form-control input-sm" placeholder="Code Imputation">
                                            </div>
                                            <label class="col-md-2 control-label">Pays :</label>
                                            <div class="col-md-4">
                                                 <input type="text" class="form-control input-sm" placeholder="Code Imputation">
                                            </div><br><br>
                                    </div><br><br>
                                    <div style="text-align: center;">
                                         <a href="#"><button type="button" class="btn btn-success"><i class="fa fa-save fa-fw"></i> Save</button></a>
                                         <button type="button" class="btn btn-default" data-dismiss="modal">Cansel</button>
                                   </div>   
                                </form>
                            </div>

                         </div>
                      </div>
                    </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->
<?php
     include('shared/partials/footer.php');
?>