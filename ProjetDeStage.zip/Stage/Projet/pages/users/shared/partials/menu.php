<!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li>
                                <a class="active" href="../accueil.php" style="text-align: center;"><i class="fa fa-home fa-fw"></i>Accueil</a>
                                <li class="divider"></li>
                            </li>
                            <li>
                               <a href="../achats/index1.php"><i class="fa fa-bar-chart-o fa-fw"></i> Achats</a><li class="divider"></li>
                            </li>
                            <li>
                                <a href="../budget/index2.php"><i class="fa fa-files-o fa-fw"></i> Budgétaire</a><li class="divider"></li>
                            </li>
                            <li>
                                <a href="../factures/index3.php"><i class="fa fa-edit fa-fw"></i> Facturation </a><li class="divider"></li>
                            </li>
                            <li>
                                <a href="#"><i class="fa fa-edit fa-fw"></i> Trésorerie </a><li class="divider"></li>
                            </li>
                            <li>
                                <a href="index4.php"><i class="fa fa-edit fa-fw"></i> Utilisateurs</a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>