<?php 
     session_start(); 
?>
<?php
     if (empty( $_SESSION['pseudo']) && empty($_SESSION['pass']))
         {
         header('location:../../index.php');
       }
     else if ( $_SESSION['pseudo']!="admin@db" && $_SESSION['pass']!="root_root")
         {
           header("location:../../index.php");
           session_destroy();
       }
?>
<?php 
           // Connexion à la base de donnés
           include('connect.php');
           if(isset($_POST)){
   try{
         //Prépation de la requête
        $stmt = $maConnexion->prepare('INSERT INTO user (username, password) VALUES (:username, :password)');
         
         //Définition des paramètres et Récupération des données du formulaire et affectation des valeurs aux paramètres de la requête
        $stmt->bindParam(':username', $_POST['username']);
        $stmt->bindParam(':password', $_POST['password']);
          
          // Exécution de la requête
         if($stmt->execute())
           {
                //Message de confirmation!!!
             echo "<script> alert(\"L'enregistrement a été effectué avec succé!!!\")</script>";
             header('location:../../index4.php');
           }
        else
           {  
               //Message d'erreur!!!
             echo "<script> alert(\"L'enregistrement a échoué,  Veuillez saisir à nouveau!!!\")</script>";
           }

        
      }
      catch (PDOException $e)
          {
                 //ERROR!!!
             die('ERROR: ' . $exception->getMessage());
          }
          }
      
?>