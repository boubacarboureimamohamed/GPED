 <?php 
     session_start(); 
?>
<?php
     if (empty( $_SESSION['pseudo']) && empty($_SESSION['pass']))
         {
         header('location:../../index.php');
       }
     else if ( $_SESSION['pseudo']!="admin@db" && $_SESSION['pass']!="root_root")
         {
           header("location:../../index.php");
           session_destroy();
       }
?>

<?php
     // Connexion à la base de donnés
           include('connect.php');

      try 
     {
       $variable =isset($_GET['supression']) ? $_GET['supression'] : die('ERROR: Record ID not found.');
       $query = "DELETE FROM user WHERE id_user = ?";
       $stmt = $maConnexion->prepare($query);
       $stmt->bindParam(1, $variable);
     
       if($stmt->execute())
         {
          header('Location: ../../index4.php?action=deleted');
         }
       else
         {
          die('La suppresion a échoué, Réssayez à nouveau!!!.');
         }
      }
 
      // error
    catch(PDOException $exception)
         {
          die('ERROR: ' . $exception->getMessage());
         }
?>