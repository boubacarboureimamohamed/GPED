<?php 
     session_start(); 
?>
<?php
     if (empty( $_SESSION['pseudo']) && empty($_SESSION['pass']))
         {
         header('location:../../index.php');
       }
     else if ( $_SESSION['pseudo']!="admin@db" && $_SESSION['pass']!="root_root")
         {
           header("location:../../index.php");
           session_destroy();
       }
?>
<?php
     include('shared/partials/header.php');

     include('shared/partials/menu.php');

     include('shared/function/connect.php');
?>
     
     <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="page-header" style="text-align: center;">Liste des utilisateurs</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="dataTable_wrapper">
                                    <div align="right">
                                        <div align="right">
                                           <button type="button" id="user_form" data-toggle="modal" data-target="#static3" class="btn btn-success"><i class="fa fa-plus fa-fw"></i>New</button>
                                        </div>
                                    </div>
                                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                        <thead>
                                            <tr>
                                                <th>Number</th>
                                                <th>Username</th>
                                                <th>Password</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <?php
                                             $reponse = $maConnexion->query('SELECT U.id_user, U.username, U.password FROM user U ORDER BY U.id_user ASC');
                                              while ($affichages = $reponse->fetch())
                                                 {
                                        ?>
                                        <tbody>
                                            <tr class="odd gradeX">
                                                <td><?php echo $affichages['id_user']; ?></td>
                                                <td><?php echo $affichages['username']; ?></td>
                                                <td><?php echo $affichages['password']; ?></td>
                                                <td>
                                                    <button type="button" id="add_button" data-toggle="modal" data-target="#static4" class="btn btn-primary"><i class="fa fa-pencil-square-o fa-fw"></i></button>
                                                    <a href="shared/function/delete.php?supression=<?php echo $donnees['id_user']; ?>">
                                                       <button class="btn btn-danger" onclick ="return(confirm('Souhaitez-vous vraiment supprimer cet enregistrement???'))"><i class="fa fa-trash-o fa-fw"></i></button>
                                                    </a>
                                                </td>
                                            </tr>
                                        </tbody>
                                        <?php
                                                }
                                             $reponse->closeCursor();
                                        ?>
                                    </table>
                                    <div id="static3" class="modal fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
                                       <form method="post" action="shared/function/insert.php" id="user_form" enctype="multipart/form-data">
                                           <div class="modal-content">
                                              <div align="center" class="modal fade" tabindex="-1" data-width="760">
                                                 <h4 class="modal-title">Add a new User</h4>
                                              </div>
                                              <div class="modal-body"><br/>
                                                  <label>Username</label>
                                                  <input type="text" name="username" id="username" class="form-control" autocomplete="off" required="required" /><br/>
                                                  <label>Password</label>
                                                  <input type="text" name="password" id="password" class="form-control" autocomplete="off" required="required" /><br/>
                                              </div>
                                              <div class="modal-footer" >
                                                  <input type="submit" class="btn btn-success" value="Add" name="action" id="action"/>
                                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                              </div>
                                          </div>
                                      </form>
                                   </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>   

<?php
     include('shared/partials/footer.php');
?>