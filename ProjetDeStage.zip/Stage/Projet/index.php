<?php
    session_start(); 
?>
<!DOCTYPE html>
<?php
   if (isset ($_GET['action']))
     {
       $_SESSION['pseudo']="";
       $_SESSION['pass']="";
     }
   $pseudo="admin@db";
   $pass="root_root";
   $erreur="";
   if (isset($_POST['username']) && isset($_POST['password'])) 
     {
       if ($_POST['username']==$pseudo && $_POST['password']==$pass)
          {
            $_SESSION['pseudo']=$_POST['username'];
            $_SESSION['pass']=$_POST['password'];
            header("location:pages/accueil.php");
          }
        else
          {
            echo "La connexion a échoué, username ou password incorrect!!! ";
          }
     }
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="author" content="">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page d'authentification</title>
         <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

          <!-- Bootstrap core css --> 
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
    	<div class="col-sm-12">
    		<div class="jumbotron">
    			<div class="form-group" id="logo">
                    <img src="images/logo.png" alt="logo">
                </div><hr>
                <form method="post" action="index.php" class="form-horizontal">
                	<div class="form-group input-group">
                    </div>
                	<div class="form-group input-group">
                         <span class="input-group-addon">
                         <span class="glyphicon glyphicon-user"></span>
                         </span>
                         <input type="email" name="username" placeholder="Username" class="form-control" required="">
                    </div>
                    <div class="form-group input-group">
                    </div>
                    <div class="form-group input-group">
                         <span class="input-group-addon">
                         <span class="glyphicon glyphicon-lock"></span>
                         </span>
                         <input type="password" name="password" placeholder="Password" class="form-control" required="required" autocomplete="off">
                    </div>
                    <div class="form-group input-group">
                    </div>
                    <div class="form-group">
                         <input type="submit" name="" class="form-control" value="Se connecter" required="required" autocomplete="off">
                    </div>
                </form>
    	    </div>
    	</div>
    </div>
</body>
</html>