<?php
    session_start(); 
?>
<!DOCTYPE html>
<?php
   if (isset ($_GET['action']))
     {
       $_SESSION['pseudo']="";
       $_SESSION['pass']="";
     }
   $pseudo="admin@db";
   $pass="root_root";
   $erreur="";
   if (isset($_POST['username']) && isset($_POST['password'])) 
     {
       if ($_POST['username']==$pseudo && $_POST['password']==$pass)
          {
            $_SESSION['pseudo']=$_POST['username'];
            $_SESSION['pass']=$_POST['password'];
            header("location:pages/accueil.php");
          }
        else
          {
            echo "La connexion a échoué, username ou password incorrect!!! ";
          }
     }

?>
<html>
<head>
	<meta charset="utf-8">
	<meta name="author" content="">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page d'authentification</title>
          <!-- Bootstrap core css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css">

          <!-- Bootstrap core css --> 
    <link rel="stylesheet" type="text/css" href="login.css">

</head>
<body>
    
      <div class="container"> 
       <div class="col-sm-10" style="width: 450px; margin-top: 30px; margin-left: 350px;" >
        <div class="jumbotron"> 
         <div class="form-group" style="text-align: center;">
            <img src="images/logo.png" alt="logo" width="300px">
           </div><hr>
             <form action="index.php" method="post" class="form-horizontal" style="margin-bottom: 30px;">
              <div class="form-group input-icon margin-top-10">
                <i class="fa fa-user"></i>
                  <input type="email" name="username" placeholder="Nom d'utilisateur" class="form-control" required="">
                   </div>
                    <div class="form-group">
                   <input type="password" name="password" placeholder="Mot de pass" class="form-control" required="">
                  </div>
                 <div class="form-group" style="margin-top: 30px;">
                <input type="submit" name="" value="Se connecter">
               </div>
           </form>
          </div>
         </div>
        </div>
          <!-- Bootstrap core js -->
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
          <!-- Bootstrap core js -->
</body>
</html>