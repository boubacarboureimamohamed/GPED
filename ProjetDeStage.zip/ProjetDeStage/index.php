<?php
    session_start(); 
?>
<!DOCTYPE html>
<?php
   if (isset ($_GET['action']))
     {
       $_SESSION['pseudo']="";
       $_SESSION['pass']="";
     }
   $pseudo="admin@db";
   $pass="root_root";
   $erreur="";
   if (isset($_POST['username']) && isset($_POST['password'])) 
     {
       if ($_POST['username']==$pseudo && $_POST['password']==$pass)
          {
            $_SESSION['pseudo']=$_POST['username'];
            $_SESSION['pass']=$_POST['password'];
            header("location:AfterLogin/public/PageAccueil/accueil.php");
          }
        else
          {
            echo "La connexion a échoué, username ou password incorrect!!! ";
          }
     }

?>
<html>
<head>
	<meta charset="utf-8">
	<meta name="author" content="">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page d'authentification</title>
          <!-- Bootstrap core css -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">
          <!-- Bootstrap core css --> 
    <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
    
      <div class="container"> 
       <div class="col-sm-10" style="width: 450px; margin-top: 30px; margin-left: 350px;" > 
        <div class="jumbotron"> 
         <div class="form-group" style="margin-top: -50px; margin-left: -38px;">
          <h1>BIENVENUE</h1>
           </div>
            <hr><h2>LOGIN</h2>
             <form action="index.php" method="post" class="form-horizontal" style="margin-bottom: 20px;">
              <div class="form-group input-group">
               <span class="input-group-addon">
                <span class="glyphicon glyphicon-user"></span>
                 </span>
                  <input type="email" name="username" placeholder="Nom d'utilisateur" class="form-control" required="">
                   </div>
                    <div class="form-group input-group">
                     <span class="input-group-addon">
                     <span class="glyphicon glyphicon-lock"></span>
                    </span>
                   <input type="password" name="password" placeholder="Mot de pass" class="form-control" required="">
                  </div>
                 <div class="form-group" style="margin-top: 50px;">
                <input type="submit" name="" value="Login">
               </div></br></br>
              <div class="form-group">
             <a href="#">Mot de pass oublié???</a>
            </div>
           </form>
          </div>
         </div>
        </div>
          <!-- Bootstrap core js -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="bootstrap/js/bootstrap.js" type="text/javascript"></script>
          <!-- Bootstrap core js -->
</body>
</html>