<?php
     session_start(); 
?>
 
<?php
     if (empty( $_SESSION['pseudo']) && empty($_SESSION['pass']))
        {
          header("location:AfterLogin/public/PageAccueil/accueil.php");
        }
     else if ( $_SESSION['pseudo']!="admin@db" && $_SESSION['pass']!="root_root")
       {
          header("location:../../Index.php");
          session_destroy();
        }
?>

<?php
     include('../../private/partials/header.php');
?> 

<?php
     include('../../private/partials/menu.php');
?> 
  	
        <!-- ************************************ -->
  	<section class="column right">
  		 <!-- Contenu -->
  		<div layout:fragment="content">
  			<h3 style="text-align: center;">Page d'accueil</h3>

  		</div>
  		  <!-- Contenu -->
  	</section>

<?php
     include('../../private/partials/footer.php');
?> 
  	
