<?php


try

    {
       $maConnexion = new PDO('mysql:host=localhost;dbname=gestion_etudiants;charset=utf8', 'root', '');
    }

catch (Exception $e)


    {
       die('Erreur : ' . $e->getMessage());
    }


?>