<section class="column left">
  		<!--Nav-Bar-->
  		<nav class="vertical-menu">
  			<a href="accueil.php" class="active">Home</a>
  			<a href="#">Blog</a>
  			<a href="#">About</a>
  			<a href="#">Faq</a>
  			 <a href="#">Service</a>
  			<a href="#">Portofolio</a>
  			<a href="#">Contact</a>
  		</nav>
  		<!--Nav-Bar-->
</section>