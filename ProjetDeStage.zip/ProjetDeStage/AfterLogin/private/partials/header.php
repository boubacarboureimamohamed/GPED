<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Bienvenue</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	  <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" type="text/css" href="">
	  <!-- Bootstrap Core CSS -->
	
</head>
<body>
	   <!-- ************************************* -->
  <header class="header">
  	<h1><a href="accueil.php">LOGO</a></h1>
  </header>
       <!-- ************************************* -->
  <div class="row">

